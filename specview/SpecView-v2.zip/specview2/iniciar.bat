@echo off
chcp 65001 >nul
title SpecView
cd /d "%~dp0"
start "" npm start
