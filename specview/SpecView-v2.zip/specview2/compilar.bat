@echo off
chcp 65001 >nul
title SpecView — Compilador de EXE
color 0E
cls

echo.
echo  SpecView — Gerador de EXE
echo  ════════════════════════════════════════════════
echo.
echo  Este processo vai gerar:
echo   - SpecView Setup.exe  (instalador)
echo   - SpecView-Portatil.exe  (abre sem instalar)
echo.
echo  [!] Pode demorar 10 a 20 minutos na primeira vez.
echo  [!] Necessita de conexao com a internet.
echo  [!] NAO feche esta janela!
echo.
pause

cd /d "%~dp0"

echo.
echo  [1/3] Verificando dependencias...
npm install --loglevel=error
if %errorlevel% neq 0 (
    echo  [ERRO] Falha. Execute instalar.bat primeiro.
    pause
    exit /b 1
)

echo.
echo  [2/3] Compilando o EXE (aguarde)...
echo.
npx electron-builder --win nsis portable --x64
if %errorlevel% neq 0 (
    echo.
    echo  [ERRO] Falha na compilacao.
    echo  Tente rodar como Administrador.
    pause
    exit /b 1
)

echo.
echo  ════════════════════════════════════════════════
echo  [SUCESSO] EXE gerado na pasta "dist\"
echo.
echo  Arquivos gerados:
echo   dist\SpecView Setup X.X.X.exe   — Instalador
echo   dist\SpecView-Portatil.exe       — Portatil
echo  ════════════════════════════════════════════════
echo.

set /p ABRIR="Abrir pasta dist? (S/N): "
if /i "%ABRIR%"=="S" explorer dist

pause
