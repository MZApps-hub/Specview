const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');
const si = require('systeminformation');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 820,
    minWidth: 900,
    minHeight: 600,
    frame: false,
    transparent: false,
    backgroundColor: '#030b12',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    icon: path.join(__dirname, '../assets/icon.png'),
    title: 'SpecView'
  });

  mainWindow.loadFile(path.join(__dirname, 'index.html'));
  mainWindow.setMenuBarVisibility(false);
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// ─── IPC HANDLERS ───────────────────────────────────────

// Dados estáticos (carregados uma vez)
ipcMain.handle('get-static-info', async () => {
  try {
    const [cpu, mem, os, gpu, disk, mb, bios] = await Promise.all([
      si.cpu(),
      si.mem(),
      si.osInfo(),
      si.graphics(),
      si.diskLayout(),
      si.baseboard(),
      si.bios()
    ]);
    return { cpu, mem, os, gpu, disk, mb, bios };
  } catch (e) {
    return { error: e.message };
  }
});

// Dados dinâmicos (atualizados em tempo real)
ipcMain.handle('get-dynamic-info', async () => {
  try {
    const [cpuLoad, mem, cpuTemp, netStats, fsStats, processes] = await Promise.all([
      si.currentLoad(),
      si.mem(),
      si.cpuTemperature(),
      si.networkStats(),
      si.fsStats(),
      si.processes()
    ]);
    return { cpuLoad, mem, cpuTemp, netStats, fsStats, processes };
  } catch (e) {
    return { error: e.message };
  }
});

// Benchmark
ipcMain.handle('run-benchmark', async () => {
  const results = {};

  // CPU benchmark
  const cpuStart = Date.now();
  let sum = 0;
  for (let i = 0; i < 5000000; i++) sum += Math.sqrt(i) * Math.sin(i);
  results.cpu = Math.round(Math.max(1000, Math.min(9999, 1e9 / (Date.now() - cpuStart))));

  // Memory benchmark
  const memStart = Date.now();
  const arr = new Float64Array(1000000);
  for (let i = 0; i < arr.length; i++) arr[i] = Math.random();
  arr.sort();
  results.mem = Math.round(Math.max(1000, Math.min(9999, 5e7 / (Date.now() - memStart))));

  results.total = Math.round((results.cpu + results.mem) / 2);
  return results;
});

// Controles da janela
ipcMain.on('window-minimize', () => mainWindow.minimize());
ipcMain.on('window-maximize', () => {
  if (mainWindow.isMaximized()) mainWindow.unmaximize();
  else mainWindow.maximize();
});
ipcMain.on('window-close', () => mainWindow.close());
