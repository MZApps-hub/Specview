// ═══════════════════════════════════════════════════════
// SPECVIEW RENDERER — Acessa hardware real via Electron IPC
// ═══════════════════════════════════════════════════════

let staticData = null;
const charts = {};
const chartData = {
  cpu: new Array(60).fill(0),
  ram: new Array(60).fill(0),
  net: new Array(60).fill(0),
};

// ─── UTILS ───────────────────────────────────────────
function gb(bytes) { return (bytes / 1e9).toFixed(1); }
function mb(bytes) { return (bytes / 1e6).toFixed(1); }
function pct(val, total) { return total > 0 ? ((val / total) * 100).toFixed(1) : '0'; }
function tempColor(t) {
  if (!t || t <= 0) return 'good';
  if (t < 60) return 'good';
  if (t < 80) return 'warn';
  return 'danger';
}
function sr(label, val, cls = '') {
  return `<div class="sr"><span class="sl">${label}</span><span class="sv ${cls}">${val}</span></div>`;
}
function clock() {
  document.getElementById('sb-clock').textContent = new Date().toLocaleTimeString('pt-BR');
}

// ─── MINI CHART ──────────────────────────────────────
function drawChart(canvasId, data, color, fill = true) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const w = canvas.parentElement.offsetWidth;
  const h = canvas.parentElement.offsetHeight || 70;
  canvas.width = w * dpr;
  canvas.height = h * dpr;
  canvas.style.width = w + 'px';
  canvas.style.height = h + 'px';
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, w, h);

  const pts = data;
  const step = w / (pts.length - 1);
  const max = 100;

  // Grid lines
  ctx.strokeStyle = 'rgba(0,212,255,0.04)';
  ctx.lineWidth = 1;
  for (let i = 1; i < 4; i++) {
    ctx.beginPath();
    ctx.moveTo(0, (h / 4) * i);
    ctx.lineTo(w, (h / 4) * i);
    ctx.stroke();
  }

  if (fill) {
    const g = ctx.createLinearGradient(0, 0, 0, h);
    const rgb = color.replace('#', '');
    const r = parseInt(rgb.substr(0, 2), 16);
    const gc2 = parseInt(rgb.substr(2, 2), 16);
    const b = parseInt(rgb.substr(4, 2), 16);
    g.addColorStop(0, `rgba(${r},${gc2},${b},0.25)`);
    g.addColorStop(1, `rgba(${r},${gc2},${b},0)`);
    ctx.beginPath();
    ctx.moveTo(0, h);
    pts.forEach((v, i) => ctx.lineTo(i * step, h - (v / max) * h));
    ctx.lineTo((pts.length - 1) * step, h);
    ctx.closePath();
    ctx.fillStyle = g;
    ctx.fill();
  }

  ctx.beginPath();
  pts.forEach((v, i) => {
    i === 0 ? ctx.moveTo(0, h - (v / max) * h) : ctx.lineTo(i * step, h - (v / max) * h);
  });
  ctx.strokeStyle = color;
  ctx.lineWidth = 1.5;
  ctx.lineJoin = 'round';
  ctx.stroke();

  // Dot at end
  const lx = (pts.length - 1) * step;
  const ly = h - (pts[pts.length - 1] / max) * h;
  ctx.beginPath();
  ctx.arc(lx, ly, 3, 0, Math.PI * 2);
  ctx.fillStyle = color;
  ctx.fill();
}

// ─── NAV ─────────────────────────────────────────────
function nav(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('page-' + page).classList.add('active');
  const idx = ['overview', 'cpu', 'memory', 'gpu', 'storage', 'network', 'temp', 'bench'];
  const btns = document.querySelectorAll('.nav-btn');
  const i = idx.indexOf(page);
  if (i >= 0 && btns[i]) btns[i].classList.add('active');
}

// ─── STATIC INFO ─────────────────────────────────────
async function loadStatic() {
  document.getElementById('load-txt').textContent = 'LENDO PROCESSADOR...';
  staticData = await window.specview.getStaticInfo();
  if (staticData.error) { console.error(staticData.error); return; }

  renderStatic();
  document.getElementById('load-txt').textContent = 'PRONTO!';
  setTimeout(() => {
    document.getElementById('loading').classList.add('hidden');
  }, 500);
}

function renderStatic() {
  const { cpu, mem, os, gpu, disk, mb, bios } = staticData;

  // CPU info
  const cpuName = `${cpu.manufacturer} ${cpu.brand}`;
  document.getElementById('ov-cpu-name').textContent = cpuName;

  // CPU Page
  document.getElementById('cpu-info').innerHTML =
    sr('Processador', cpuName, 'hi') +
    sr('Fabricante', cpu.manufacturer) +
    sr('Velocidade Base', cpu.speed + ' GHz', 'good') +
    sr('Velocidade Máx', cpu.speedMax + ' GHz', 'hi') +
    sr('Núcleos Físicos', cpu.physicalCores, 'good') +
    sr('Threads', cpu.cores, 'good') +
    sr('Soquete', cpu.socket) +
    sr('Cache L1d', cpu.cache?.l1d ? Math.round(cpu.cache.l1d / 1024) + ' KB' : '—') +
    sr('Cache L2', cpu.cache?.l2 ? Math.round(cpu.cache.l2 / 1024) + ' KB' : '—') +
    sr('Cache L3', cpu.cache?.l3 ? Math.round(cpu.cache.l3 / 1024 / 1024) + ' MB' : '—') +
    sr('Virtualização', cpu.virtualization ? 'Suportada' : 'Não', cpu.virtualization ? 'good' : 'warn');

  // OS
  const osStr = `${os.distro} ${os.release}`;
  document.getElementById('ov-os').innerHTML =
    sr('Sistema', osStr, 'hi') +
    sr('Build', os.build || os.kernel) +
    sr('Arquitetura', os.arch, 'good') +
    sr('Hostname', os.hostname) +
    sr('UEFI/BIOS', bios.vendor + ' ' + bios.version);

  // GPU
  const gpuList = gpu.controllers || [];
  let gpuHtml = '';
  gpuList.forEach(g => {
    gpuHtml += `<div class="grid" style="margin-bottom:12px"><div class="card"><div class="ch"><span class="ct">${g.model}</span></div>` +
      sr('Fabricante', g.vendor, 'hi') +
      sr('VRAM', g.vram ? g.vram + ' MB' : '—', 'good') +
      sr('Tipo VRAM', g.vramDynamic ? 'Dinâmica' : 'Dedicada') +
      sr('Driver', g.driverVersion || '—') +
      sr('Res. Atual', g.currentResX ? g.currentResX + 'x' + g.currentResY : '—', 'good') +
      sr('Frequência', g.currentRefreshRate ? g.currentRefreshRate + ' Hz' : '—') +
      `</div></div>`;
  });
  document.getElementById('gpu-cards').innerHTML = gpuHtml || sr('GPU', 'Não detectada', 'warn');
  document.getElementById('ov-gpu').innerHTML =
    gpuList.length > 0
      ? sr('GPU', gpuList[0].model, 'hi') + sr('VRAM', gpuList[0].vram ? gpuList[0].vram + ' MB' : '—', 'good') + sr('Driver', gpuList[0].driverVersion || '—')
      : sr('GPU', 'Não detectada', 'warn');

  // Disk
  const disks = disk || [];
  let diskHtml = '';
  disks.forEach(d => {
    diskHtml += `<div class="card" style="margin-bottom:12px"><div class="ch"><span class="ct">${d.type || 'DISCO'} — ${d.name}</span></div>` +
      sr('Modelo', d.name, 'hi') +
      sr('Tipo', d.type, 'good') +
      sr('Tamanho', gb(d.size) + ' GB') +
      sr('Interface', d.interfaceType || '—') +
      sr('Fabricante', d.vendor || '—') +
      sr('S/N', d.serialNum || '—') +
      `</div>`;
  });
  document.getElementById('storage-cards').innerHTML = diskHtml;
  document.getElementById('ov-disk').innerHTML = disks.length > 0
    ? sr('Disco', disks[0].name, 'hi') + sr('Tamanho', gb(disks[0].size) + ' GB', 'good') + sr('Tipo', disks[0].type)
    : sr('Disco', '—');

  // Motherboard
  const mbHtml =
    sr('Fabricante', mb.manufacturer, 'hi') +
    sr('Modelo', mb.model, 'good') +
    sr('Versão', mb.version) +
    sr('Serial', mb.serial || '—') +
    sr('BIOS', bios.vendor + ' ' + bios.version);
  document.getElementById('ov-mb').innerHTML = mbHtml;

  // Memory details
  const totalGB = gb(mem.total);
  document.getElementById('mem-total-v').textContent = totalGB;
  document.getElementById('mem-details').innerHTML =
    sr('Total', totalGB + ' GB', 'hi') +
    sr('Tipo', 'DDR4/DDR5') +
    sr('Swap Total', gb(mem.swaptotal) + ' GB') +
    sr('Swap Usado', gb(mem.swapused) + ' GB', 'warn');
}

// ─── DYNAMIC INFO ────────────────────────────────────
async function updateDynamic() {
  const d = await window.specview.getDynamicInfo();
  if (!d || d.error) return;

  const { cpuLoad, mem, cpuTemp, netStats, fsStats, processes } = d;

  // CPU load
  const totalPct = cpuLoad.currentLoad?.toFixed(1) || '0';
  chartData.cpu.push(parseFloat(totalPct));
  if (chartData.cpu.length > 60) chartData.cpu.shift();

  document.getElementById('ov-cpu-pct').textContent = totalPct + '%';
  document.getElementById('cpu-rt-pct').textContent = totalPct + '%';
  document.getElementById('sb-cpu').textContent = totalPct + '%';
  document.getElementById('ov-cpu-badge').textContent =
    totalPct > 80 ? 'ALTO' : totalPct > 50 ? 'MÉDIO' : 'NORMAL';

  // CPU cores bars
  const coreLoads = cpuLoad.cpus || [];
  let coresHtml = '';
  coreLoads.slice(0, 16).forEach((c, i) => {
    const p = c.load?.toFixed(0) || 0;
    const col = p > 80 ? 'var(--neon3)' : p > 50 ? '#ffd700' : 'var(--neon)';
    coresHtml += `<div class="br"><span class="bl">Core ${i + 1}</span><div class="bt"><div class="bf" style="width:${p}%;background:${col}"></div></div><span class="bp">${p}%</span></div>`;
  });
  const cpuCoresEl = document.getElementById('cpu-cores');
  if (cpuCoresEl) cpuCoresEl.innerHTML = coresHtml;

  // RAM
  const usedGB = gb(mem.active || mem.used);
  const totalGB = gb(mem.total);
  const freeGB = gb(mem.available || mem.free);
  const cacheGB = gb(mem.cached || 0);
  const usedPct = parseFloat(pct(mem.active || mem.used, mem.total));
  const freePct = parseFloat(pct(mem.available || mem.free, mem.total));
  const cachePct = Math.max(0, 100 - usedPct - freePct);

  chartData.ram.push(usedPct);
  if (chartData.ram.length > 60) chartData.ram.shift();

  document.getElementById('ov-ram-pct').textContent = usedPct.toFixed(1) + '%';
  document.getElementById('ov-ram-badge').textContent = usedGB + '/' + totalGB + 'GB';
  document.getElementById('ov-ram-sub').textContent = usedGB + ' / ' + totalGB + ' GB';
  document.getElementById('sb-ram').textContent = usedGB + 'GB';

  const setEl = (id, val) => { const e = document.getElementById(id); if (e) e.textContent = val; };
  setEl('mem-used-v', usedGB);
  setEl('mem-free-v', freeGB);
  setEl('mem-total-v', totalGB);

  const setBar = (id, pctId, val) => {
    const e = document.getElementById(id); if (e) e.style.width = val + '%';
    const p = document.getElementById(pctId); if (p) p.textContent = val.toFixed(0) + '%';
  };
  setBar('mem-bar-used', 'mem-bar-pct', usedPct);
  setBar('mem-bar-cache', 'mem-cache-pct', cachePct);
  setBar('mem-bar-free', 'mem-free-pct', freePct);

  // Temperature
  const temps = cpuTemp;
  const mainTemp = temps?.main > 0 ? temps.main : (temps?.cores?.length ? Math.max(...temps.cores) : null);
  const tempStr = mainTemp ? mainTemp + '°C' : 'N/A';
  const tempCls = mainTemp ? tempColor(mainTemp) : 'warn';

  document.getElementById('ov-temp-cpu').textContent = tempStr;
  document.getElementById('ov-temp-cpu').className = 'tv ' + tempCls;
  document.getElementById('sb-temp').textContent = tempStr;

  // GPU temp (if available)
  const gpuTemp = cpuTemp?.gpu;
  document.getElementById('ov-temp-gpu').textContent = gpuTemp ? gpuTemp + '°C' : 'N/A';
  document.getElementById('ov-temp-gpu').className = 'tv ' + (gpuTemp ? tempColor(gpuTemp) : 'warn');

  // Temp page
  let tempCardsHtml = '';
  if (temps?.cores?.length) {
    temps.cores.forEach((t, i) => {
      const tc = tempColor(t);
      tempCardsHtml += `<div class="card"><div class="ch"><span class="ct">CORE ${i + 1}</span></div><div class="metric"><div class="metric-val ${tc}">${t > 0 ? t + '°C' : 'N/A'}</div><div class="metric-lbl">TEMPERATURA</div></div></div>`;
    });
  } else {
    tempCardsHtml = `<div class="card card-full"><div class="sr"><span class="sv warn">Sensores de temperatura não disponíveis. Execute o app como Administrador para obter leituras de temperatura.</span></div></div>`;
  }
  if (mainTemp) {
    tempCardsHtml = `<div class="card"><div class="ch"><span class="ct">CPU TOTAL</span></div><div class="metric"><div class="metric-val ${tempCls}">${mainTemp}°C</div><div class="metric-lbl">MÁX. CPU</div></div></div>` + tempCardsHtml;
  }
  const tempEl = document.getElementById('temp-cards');
  if (tempEl) tempEl.innerHTML = tempCardsHtml;

  // Network
  const net = netStats?.[0];
  if (net) {
    const dlMB = (net.rx_sec / 1e6).toFixed(2);
    const ulMB = (net.tx_sec / 1e6).toFixed(2);
    const maxMB = Math.max(parseFloat(dlMB), parseFloat(ulMB), 1);
    chartData.net.push((parseFloat(dlMB) / maxMB) * 100);
    if (chartData.net.length > 60) chartData.net.shift();
    setEl('net-dl', dlMB);
    setEl('net-ul', ulMB);
  }

  // Processes
  const procs = (processes?.list || [])
    .filter(p => p.cpu > 0)
    .sort((a, b) => b.cpu - a.cpu)
    .slice(0, 12);
  const procEl = document.getElementById('proc-list');
  if (procEl && procs.length > 0) {
    procEl.innerHTML = procs.map(p =>
      `<div class="proc-row">
        <span class="proc-name">${p.name}</span>
        <span class="proc-cpu">${p.cpu.toFixed(1)}%</span>
        <span class="proc-mem">${(p.memRss / 1e6).toFixed(0)}MB</span>
      </div>`
    ).join('');
  }

  // Draw charts
  drawChart('chart-cpu-ov', chartData.cpu, '#00d4ff');
  drawChart('chart-ram-ov', chartData.ram, '#a855f7');
  drawChart('chart-cpu-rt', chartData.cpu, '#00d4ff');
  drawChart('chart-ram-rt', chartData.ram, '#a855f7');
  drawChart('chart-net', chartData.net, '#00ff88');

  // Net info page
  const netInfoEl = document.getElementById('net-info');
  if (netInfoEl && net) {
    netInfoEl.innerHTML =
      sr('Interface', net.iface, 'hi') +
      sr('Total Recebido', gb(net.rx_bytes) + ' GB', 'good') +
      sr('Total Enviado', gb(net.tx_bytes) + ' GB') +
      sr('Erros RX', net.rx_errors) +
      sr('Erros TX', net.tx_errors);
  }
}

// ─── BENCHMARK ───────────────────────────────────────
let benchRunning = false;
async function runBenchmark() {
  if (benchRunning) return;
  benchRunning = true;
  const btn = document.getElementById('bench-btn');
  const status = document.getElementById('bench-status');
  btn.textContent = '⏳ EXECUTANDO...';
  btn.disabled = true;
  status.textContent = 'Iniciando testes...';
  ['b-cpu', 'b-mem', 'b-tot'].forEach(id => { const e = document.getElementById(id); if (e) e.textContent = '…'; });
  ['bp-cpu', 'bp-mem', 'bp-tot'].forEach(id => { const e = document.getElementById(id); if (e) e.style.width = '0%'; });

  status.textContent = 'Testando CPU e Memória via Node.js...';
  const result = await window.specview.runBenchmark();

  animScore('b-cpu', 'bp-cpu', result.cpu, 9999);
  animScore('b-mem', 'bp-mem', result.mem, 9999);
  await new Promise(r => setTimeout(r, 1000));
  animScore('b-tot', 'bp-tot', result.total, 9999);

  const rank = result.total > 8000 ? '🏆 EXCELENTE' :
    result.total > 6000 ? '🥇 MUITO BOM' :
      result.total > 4000 ? '🥈 BOM' : '🥉 BÁSICO';
  document.getElementById('b-rank').textContent = rank;

  status.textContent = `✓ Concluído — Score: ${result.total.toLocaleString('pt-BR')}`;
  btn.textContent = '▶ EXECUTAR BENCHMARK';
  btn.disabled = false;
  benchRunning = false;
}

function animScore(id, progId, val, max) {
  let cur = 0;
  const step = val / 40;
  const t = setInterval(() => {
    cur = Math.min(cur + step, val);
    const e = document.getElementById(id); if (e) e.textContent = Math.round(cur).toLocaleString('pt-BR');
    const p = document.getElementById(progId); if (p) p.style.width = (cur / max * 100) + '%';
    if (cur >= val) clearInterval(t);
  }, 25);
}

// ─── SHARE / EXPORT ──────────────────────────────────
function openShare() {
  if (!staticData) return;
  const { cpu, mem, os, gpu } = staticData;
  const gpuModel = gpu.controllers?.[0]?.model || 'N/A';
  const txt = `
╔══════════════════════════════════════╗
║         SPECVIEW — RELATÓRIO         ║
╠══════════════════════════════════════╣
║ CPU:  ${(cpu.manufacturer + ' ' + cpu.brand).substring(0, 36).padEnd(36)} ║
║ Núcl: ${String(cpu.cores).padEnd(36)} ║
║ RAM:  ${(gb(mem.total) + ' GB').padEnd(36)} ║
║ GPU:  ${gpuModel.substring(0, 36).padEnd(36)} ║
║ OS:   ${(os.distro + ' ' + os.release).substring(0, 36).padEnd(36)} ║
║ Arq:  ${os.arch.padEnd(36)} ║
╚══════════════════════════════════════╝
Gerado: ${new Date().toLocaleString('pt-BR')}
via SpecView Desktop v2.0`.trim();
  document.getElementById('share-txt').textContent = txt;
  document.getElementById('modal').classList.add('open');
}

async function copyShare() {
  const txt = document.getElementById('share-txt').textContent;
  await navigator.clipboard.writeText(txt);
  const btn = event.target;
  btn.textContent = '✓ Copiado!';
  setTimeout(() => btn.textContent = '📋 Copiar', 2000);
}

function closeModal() { document.getElementById('modal').classList.remove('open'); }

function exportReport() { window.print(); }

// ─── INIT ────────────────────────────────────────────
async function init() {
  await loadStatic();
  await updateDynamic();
  setInterval(updateDynamic, 2000);
  setInterval(clock, 1000);
  clock();
}

document.getElementById('modal').addEventListener('click', function (e) {
  if (e.target === this) closeModal();
});

init();
