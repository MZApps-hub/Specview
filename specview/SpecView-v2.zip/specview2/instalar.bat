@echo off
chcp 65001 >nul
title SpecView — Instalador
color 0B
cls

echo.
echo  ███████╗██████╗ ███████╗ ██████╗██╗   ██╗██╗███████╗██╗    ██╗
echo  ██╔════╝██╔══██╗██╔════╝██╔════╝██║   ██║██║██╔════╝██║    ██║
echo  ███████╗██████╔╝█████╗  ██║     ██║   ██║██║█████╗  ██║ █╗ ██║
echo  ╚════██║██╔═══╝ ██╔══╝  ██║     ╚██╗ ██╔╝██║██╔══╝  ██║███╗██║
echo  ███████║██║     ███████╗╚██████╗ ╚████╔╝ ██║███████╗╚███╔███╔╝
echo  ╚══════╝╚═╝     ╚══════╝ ╚═════╝  ╚═══╝  ╚═╝╚══════╝ ╚══╝╚══╝
echo.
echo  Monitor de Hardware para Windows
echo  ════════════════════════════════════════════════
echo.

:: Verificar Node.js
echo  [1/4] Verificando Node.js...
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  [!] Node.js NAO encontrado!
    echo  [!] Abrindo download do Node.js...
    echo  [!] Instale o Node.js e execute este arquivo novamente.
    echo.
    timeout /t 3 >nul
    start https://nodejs.org/dist/v20.10.0/node-v20.10.0-x64.msi
    echo  Pressione qualquer tecla apos instalar o Node.js...
    pause >nul
    echo.
    echo  Verificando novamente...
    node --version >nul 2>&1
    if %errorlevel% neq 0 (
        echo  [ERRO] Node.js ainda nao detectado. Reinicie e tente novamente.
        pause
        exit /b 1
    )
)

for /f "tokens=*" %%i in ('node --version') do set NODE_VER=%%i
echo  [OK] Node.js %NODE_VER% encontrado!
echo.

:: Verificar npm
echo  [2/4] Verificando npm...
npm --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERRO] npm nao encontrado. Reinstale o Node.js.
    pause
    exit /b 1
)
echo  [OK] npm encontrado!
echo.

:: Instalar dependencias
echo  [3/4] Instalando dependencias (pode demorar 2-5 minutos)...
echo  [!] Aguarde, nao feche esta janela...
echo.
npm install --loglevel=error
if %errorlevel% neq 0 (
    echo.
    echo  [ERRO] Falha ao instalar dependencias.
    echo  Tente rodar como Administrador.
    pause
    exit /b 1
)
echo.
echo  [OK] Dependencias instaladas!
echo.

:: Criar atalho na area de trabalho
echo  [4/4] Criando atalho na Area de Trabalho...
set SCRIPT_DIR=%~dp0
set DESKTOP=%USERPROFILE%\Desktop
set SHORTCUT=%DESKTOP%\SpecView.bat

echo @echo off > "%SHORTCUT%"
echo cd /d "%SCRIPT_DIR%" >> "%SHORTCUT%"
echo start "" npm start >> "%SHORTCUT%"

echo  [OK] Atalho criado na Area de Trabalho!
echo.
echo  ════════════════════════════════════════════════
echo  [SUCESSO] SpecView instalado com sucesso!
echo.
echo  Para abrir o SpecView:
echo   - Clique duas vezes em "SpecView.bat" na Area de Trabalho
echo   - Ou execute "iniciar.bat" nesta pasta
echo.
echo  Para gerar o .EXE standalone:
echo   - Execute "compilar.bat" (pode demorar 10-15 min)
echo  ════════════════════════════════════════════════
echo.

set /p ABRIR="Deseja abrir o SpecView agora? (S/N): "
if /i "%ABRIR%"=="S" (
    echo  Iniciando SpecView...
    start "" npm start
)

pause
