@echo off
title SpecView v7 - Instalador
color 0B
cls

echo.
echo  ================================
echo   SPECVIEW v7 - Instalador
echo  ================================
echo.

:: Verifica Node.js
echo [1/4] Verificando Node.js...
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  Node.js nao encontrado!
    echo  Abrindo pagina de download...
    start https://nodejs.org/dist/v20.10.0/node-v20.10.0-x64.msi
    echo.
    echo  1. Instale o Node.js
    echo  2. Reinicie o computador
    echo  3. Execute este arquivo novamente
    echo.
    pause
    exit /b 1
)
for /f "tokens=*" %%v in ('node --version') do set NV=%%v
echo [OK] Node.js %NV% encontrado!
echo.

:: Instala dependencias
echo [2/4] Instalando dependencias (aguarde)...
cd /d "%~dp0"
call npm install
if %errorlevel% neq 0 (
    echo ERRO. Tente rodar como Administrador.
    pause
    exit /b 1
)
echo [OK] Dependencias instaladas!
echo.

:: Instala electron-builder
echo [3/4] Instalando electron-builder...
call npm install electron-builder --save-dev
echo [OK] electron-builder instalado!
echo.

:: Cria launcher.vbs (abre app sem janela preta)
echo [4/4] Criando atalho na Area de Trabalho...
set PASTA=%~dp0

:: Remove barra final se tiver
if "%PASTA:~-1%"=="\" set PASTA=%PASTA:~0,-1%

:: Escreve o launcher.vbs que abre sem terminal
(
echo Set oShell = CreateObject^("WScript.Shell"^)
echo oShell.CurrentDirectory = "%PASTA%"
echo oShell.Run "cmd /c npm start", 0, False
) > "%PASTA%\launcher.vbs"

:: Cria atalho via VBScript (sem PowerShell)
set DESK=%USERPROFILE%\Desktop
(
echo Set oWS = WScript.CreateObject^("WScript.Shell"^)
echo Set oLink = oWS.CreateShortcut^("%DESK%\SpecView.lnk"^)
echo oLink.TargetPath = "wscript.exe"
echo oLink.Arguments = """%PASTA%\launcher.vbs"""
echo oLink.WorkingDirectory = "%PASTA%"
echo oLink.Description = "SpecView - Monitor de Hardware"
echo oLink.IconLocation = "%PASTA%\assets\icon.ico"
echo oLink.WindowStyle = 1
echo oLink.Save
) > "%TEMP%\sv_atalho.vbs"

wscript //nologo "%TEMP%\sv_atalho.vbs"
del "%TEMP%\sv_atalho.vbs" >nul 2>&1

if exist "%DESK%\SpecView.lnk" (
    echo [OK] Atalho criado na Area de Trabalho!
) else (
    echo [AVISO] Atalho nao criado - use iniciar.bat para abrir.
)
echo.

echo ================================
echo  INSTALACAO CONCLUIDA!
echo ================================
echo.
echo  Proximo uso: clique em "SpecView" na Area de Trabalho
echo  (abre sem janela preta, igual Discord)
echo.
echo  Para gerar .EXE standalone: execute compilar.bat
echo.
set /p ABRIR=Abrir o SpecView agora? (S/N): 
if /i "%ABRIR%"=="S" (
    wscript //nologo "%PASTA%\launcher.vbs"
)
pause
