// ═══════════════════════════════════════════════════
// SPECVIEW v4.0 — RENDERER
// ═══════════════════════════════════════════════════

let staticData = null;
const cdata = { cpu: new Array(60).fill(0), ram: new Array(60).fill(0), net: new Array(60).fill(0) };

// ─── UTILS ──────────────────────────────────────────
const gb  = b => (b/1e9).toFixed(1);
const mb2 = b => (b/1e6).toFixed(2);
const pct = (v,t) => t>0?((v/t)*100).toFixed(1):'0';
const tc  = t => !t||t<=0?'wa':t<60?'go':t<80?'wa':'da';
const ss  = (id,v) => { const e=document.getElementById(id); if(e) e.textContent=v; };
const sr  = (l,v,c='') => `<div class="sr"><span class="sl">${l}</span><span class="sv ${c}">${v}</span></div>`;
const setBar = (id,pid,v) => {
  const e=document.getElementById(id); if(e) e.style.width=Math.min(100,v)+'%';
  const p=document.getElementById(pid); if(p) p.textContent=v.toFixed(0)+'%';
};

// ─── NAV ────────────────────────────────────────────
function nav(page) {
  document.querySelectorAll('.pg').forEach(p=>p.classList.remove('on'));
  document.querySelectorAll('.nb').forEach(b=>b.classList.remove('on'));
  document.getElementById('pg-'+page).classList.add('on');
  const pages=['ov','cpu','ram','gpu','disk','net','tmp','fps','gm'];
  const i=pages.indexOf(page);
  const btns=document.querySelectorAll('.nb');
  if(i>=0&&btns[i]) btns[i].classList.add('on');
}

// ─── MINI CHART ─────────────────────────────────────
function drawChart(id, data, color) {
  const canvas=document.getElementById(id); if(!canvas) return;
  const ctx=canvas.getContext('2d');
  const dpr=window.devicePixelRatio||1;
  const w=canvas.parentElement.offsetWidth||300;
  const h=canvas.parentElement.offsetHeight||60;
  canvas.width=w*dpr; canvas.height=h*dpr;
  canvas.style.width=w+'px'; canvas.style.height=h+'px';
  ctx.scale(dpr,dpr);
  ctx.clearRect(0,0,w,h);
  const step=w/(data.length-1);
  ctx.strokeStyle='rgba(0,212,255,0.04)'; ctx.lineWidth=1;
  [.25,.5,.75].forEach(f=>{ctx.beginPath();ctx.moveTo(0,h*f);ctx.lineTo(w,h*f);ctx.stroke();});
  const hex=color.replace('#','');
  const r=parseInt(hex.slice(0,2),16),g=parseInt(hex.slice(2,4),16),b=parseInt(hex.slice(4,6),16);
  const grad=ctx.createLinearGradient(0,0,0,h);
  grad.addColorStop(0,`rgba(${r},${g},${b},0.25)`);
  grad.addColorStop(1,`rgba(${r},${g},${b},0)`);
  ctx.beginPath(); ctx.moveTo(0,h);
  data.forEach((v,i)=>ctx.lineTo(i*step,h-(v/100)*h));
  ctx.lineTo((data.length-1)*step,h); ctx.closePath();
  ctx.fillStyle=grad; ctx.fill();
  ctx.beginPath();
  data.forEach((v,i)=>i===0?ctx.moveTo(0,h-(v/100)*h):ctx.lineTo(i*step,h-(v/100)*h));
  ctx.strokeStyle=color; ctx.lineWidth=1.5; ctx.lineJoin='round'; ctx.stroke();
  const lv=data[data.length-1];
  ctx.beginPath(); ctx.arc((data.length-1)*step,h-(lv/100)*h,3,0,Math.PI*2);
  ctx.fillStyle=color; ctx.fill();
}

// ─── STATIC ─────────────────────────────────────────
async function loadStatic() {
  ss('ldt','LENDO HARDWARE...');
  try {
    staticData = await window.sv.getStatic();
    if(staticData && !staticData.error) renderStatic();
    else console.warn('Static data error:', staticData?.error);
  } catch(e) {
    console.error('loadStatic error:', e);
  }
  ss('ldt','PRONTO!');
  // SEMPRE esconde a tela de loading, mesmo se der erro
  setTimeout(()=>document.getElementById('ld').classList.add('hd'), 300);
}

function renderStatic() {
  const {cpu,mem,os,gpu,disk,mb,bios} = staticData;
  const cpuName=`${cpu.manufacturer} ${cpu.brand}`;
  ss('ov-cn',cpuName);

  // OS
  document.getElementById('ov-os').innerHTML=
    sr('Sistema',`${os.distro} ${os.release}`,'hi')+
    sr('Build',os.build||os.kernel)+
    sr('Arquitetura',os.arch,'go')+
    sr('Hostname',os.hostname)+
    sr('BIOS',`${bios.vendor} ${bios.version}`);

  // CPU page
  document.getElementById('cpu-info').innerHTML=
    sr('Modelo',cpuName,'hi')+
    sr('Fabricante',cpu.manufacturer)+
    sr('Clock Base',cpu.speed+' GHz','go')+
    sr('Clock Máx',cpu.speedMax+' GHz','hi')+
    sr('Núcleos Físicos',cpu.physicalCores,'go')+
    sr('Threads',cpu.cores,'go')+
    sr('Soquete',cpu.socket)+
    sr('Cache L2',cpu.cache?.l2?Math.round(cpu.cache.l2/1024)+' KB':'—')+
    sr('Cache L3',cpu.cache?.l3?Math.round(cpu.cache.l3/1024/1024)+' MB':'—')+
    sr('Virtualização',cpu.virtualization?'Sim':'Não');

  // GPU — mostra TODAS incluindo integrada
  const gpus=gpu.controllers||[];
  document.getElementById('gpu-cards').innerHTML=gpus.length?gpus.map(g=>
    `<div class="cd" style="margin-bottom:10px">
      <div class="ch"><div class="ci" style="background:rgba(0,255,136,.1)">🎮</div>
      <span class="ct">${g.model}</span>
      <span class="cbg" style="color:${g.vramDynamic?'#ffd700':'var(--n2)'};border-color:${g.vramDynamic?'rgba(255,215,0,.3)':'rgba(0,255,136,.3)'}">${g.vramDynamic?'INTEGRADA':'DEDICADA'}</span></div>
      ${sr('Fabricante',g.vendor,'hi')}
      ${sr('VRAM',g.vram?g.vram+' MB':'Compartilhada',g.vram&&!g.vramDynamic?'go':'wa')}
      ${sr('Tipo',g.vramDynamic?'Integrada (RAM compartilhada)':'Dedicada')}
      ${sr('Driver',g.driverVersion||'—')}
      ${sr('Resolução',g.currentResX?g.currentResX+'x'+g.currentResY:'—','go')}
      ${sr('Refresh',g.currentRefreshRate?g.currentRefreshRate+' Hz':'—')}
    </div>`).join(''): sr('GPU','Não detectada','wa');

  // Pega a GPU principal (prefere dedicada, se não integrada)
  const mainGpu = gpus.find(g=>!g.vramDynamic) || gpus[0];
  document.getElementById('ov-gp').innerHTML=mainGpu?
    sr('Modelo',mainGpu.model,'hi')+
    sr('Tipo',mainGpu.vramDynamic?'Integrada':'Dedicada',mainGpu.vramDynamic?'wa':'go')+
    sr('VRAM',mainGpu.vram?mainGpu.vram+' MB':'Compartilhada'):
    sr('GPU','—');

  // Disk
  document.getElementById('disk-cards').innerHTML=(disk||[]).map(d=>
    `<div class="cd" style="margin-bottom:10px">
      <div class="ch"><div class="ci" style="background:rgba(255,215,0,.1)">💿</div><span class="ct">${d.type||'DISCO'}</span></div>
      ${sr('Modelo',d.name,'hi')}
      ${sr('Tamanho',gb(d.size)+' GB','go')}
      ${sr('Tipo',d.type||'—')}
      ${sr('Interface',d.interfaceType||'—')}
      ${sr('Fabricante',d.vendor||'—')}
    </div>`).join('')||sr('Disco','—','wa');

  // MB
  document.getElementById('ov-mb').innerHTML=
    sr('Fabricante',mb.manufacturer,'hi')+
    sr('Modelo',mb.model,'go')+
    sr('Versão',mb.version)+
    sr('BIOS',`${bios.vendor} ${bios.version}`);

  // Memory details
  ss('m-to',gb(mem.total));
  document.getElementById('mem-det').innerHTML=
    sr('Total',gb(mem.total)+' GB','hi')+
    sr('Swap Total',gb(mem.swaptotal)+' GB')+
    sr('Swap Usado',gb(mem.swapused)+' GB');

  // Init games with detected hardware
  initGames(cpu, mem, gpus);
  initFpsCanvas();
}

// ─── DYNAMIC ────────────────────────────────────────
async function updateDynamic() {
  const d = await window.sv.getDynamic();
  if(!d||d.error) return;
  const {cpuLoad,mem,cpuTemp,netStats,processes}=d;

  // CPU
  const cp=(cpuLoad.currentLoad||0).toFixed(1);
  cdata.cpu.push(parseFloat(cp)); if(cdata.cpu.length>60) cdata.cpu.shift();
  ss('ov-cp',cp+'%'); ss('cpu-pct',cp+'%'); ss('sb-cpu',cp+'%');
  const cb=document.getElementById('ov-cb');
  if(cb){cb.textContent=cp>80?'ALTO':cp>50?'MÉDIO':'NORMAL';cb.style.color=cp>80?'var(--n3)':cp>50?'#ffd700':'var(--n2)';}

  // CPU cores
  const cores=cpuLoad.cpus||[];
  const ce=document.getElementById('cpu-cores');
  if(ce) ce.innerHTML=cores.slice(0,16).map((c,i)=>{
    const p=(c.load||0).toFixed(0);
    const col=p>80?'var(--n3)':p>50?'#ffd700':'var(--n)';
    return `<div class="br"><span class="brl">Core ${i+1}</span><div class="brt"><div class="brf" style="width:${p}%;background:${col}"></div></div><span class="brp">${p}%</span></div>`;
  }).join('');

  // RAM
  const usedP=parseFloat(pct(mem.active||mem.used,mem.total));
  const freeP=parseFloat(pct(mem.available||mem.free,mem.total));
  const cacheP=Math.max(0,100-usedP-freeP);
  cdata.ram.push(usedP); if(cdata.ram.length>60) cdata.ram.shift();
  ss('ov-rp',usedP.toFixed(1)+'%');
  ss('ov-rs',gb(mem.active||mem.used)+' / '+gb(mem.total)+' GB');
  ss('sb-ram',gb(mem.active||mem.used)+'GB');
  const rb=document.getElementById('ov-rb'); if(rb) rb.textContent=gb(mem.active||mem.used)+'/'+gb(mem.total)+'GB';
  ss('m-us',gb(mem.active||mem.used)); ss('m-fr',gb(mem.available||mem.free));
  setBar('mb-us','mp-us',usedP); setBar('mb-ca','mp-ca',cacheP); setBar('mb-fr','mp-fr',freeP);

  // TEMPERATURE
  const temps=cpuTemp||{};
  const coreTemps=(temps.cores||[]).filter(t=>t>0);
  const mainTemp=temps.main>0?temps.main:(coreTemps.length?Math.round(coreTemps.reduce((a,b)=>a+b,0)/coreTemps.length):null);
  const maxTemp=coreTemps.length?Math.max(...coreTemps):mainTemp;
  const gpuTemp=temps.gpu>0?temps.gpu:null;
  const tStr=t=>t?t+'°C':'N/A';

  ss('ov-tc',tStr(mainTemp)); ss('ov-tg',tStr(gpuTemp)); ss('ov-tm',tStr(maxTemp));
  ss('sb-tmp',tStr(mainTemp||maxTemp));
  ['ov-tc','ov-tg','ov-tm'].forEach((id,i)=>{
    const e=document.getElementById(id); if(!e) return;
    const temps_=[mainTemp,gpuTemp,maxTemp];
    e.className='tv '+tc(temps_[i]);
  });

  // Temp page
  const te=document.getElementById('tmp-cards');
  if(te){
    if(coreTemps.length>0||mainTemp||gpuTemp){
      let h='';
      if(mainTemp) h+=`<div class="cd"><div class="mx"><div class="mv ${tc(mainTemp)}">${mainTemp}°C</div><div class="ml">CPU MÉDIA</div></div></div>`;
      if(gpuTemp)  h+=`<div class="cd"><div class="mx"><div class="mv ${tc(gpuTemp)}">${gpuTemp}°C</div><div class="ml">GPU</div></div></div>`;
      if(maxTemp&&maxTemp!==mainTemp) h+=`<div class="cd"><div class="mx"><div class="mv ${tc(maxTemp)}">${maxTemp}°C</div><div class="ml">MÁXIMA</div></div></div>`;
      coreTemps.forEach((t,i)=>{h+=`<div class="cd"><div class="mx"><div class="mv ${tc(t)}">${t}°C</div><div class="ml">CORE ${i+1}</div></div></div>`;});
      te.innerHTML=h;
    } else {
      te.innerHTML=`<div class="cd cf warn-box">Nenhum sensor detectado. Execute como Administrador para leitura de temperatura.</div>`;
    }
  }

  // Network
  const net=netStats?.[0];
  if(net){
    const dl=mb2(net.rx_sec||0); const ul=mb2(net.tx_sec||0);
    cdata.net.push(Math.min(100,parseFloat(dl)*8));
    if(cdata.net.length>60) cdata.net.shift();
    ss('net-dl',dl); ss('net-ul',ul); ss('sb-net',dl+' MB/s');
    const ni=document.getElementById('net-info');
    if(ni) ni.innerHTML=
      sr('Interface',net.iface,'hi')+
      sr('Total RX',gb(net.rx_bytes)+' GB','go')+
      sr('Total TX',gb(net.tx_bytes)+' GB')+
      sr('Operacional',net.operstate||'—','go');
  }

  // Processes
  const procs=(processes?.list||[]).filter(p=>p.cpu>0.1).sort((a,b)=>b.cpu-a.cpu).slice(0,12);
  const pl=document.getElementById('proc-list');
  if(pl&&procs.length) pl.innerHTML=procs.map(p=>
    `<div class="pr"><span class="pn">${p.name}</span><span class="pc">${p.cpu.toFixed(1)}%</span><span class="pm">${(p.memRss/1e6).toFixed(0)}MB</span></div>`
  ).join('');

  // Charts
  drawChart('ch-cp',cdata.cpu,'#00d4ff');
  drawChart('ch-rp',cdata.ram,'#a855f7');
  drawChart('ch-crt',cdata.cpu,'#00d4ff');
  drawChart('ch-rrt',cdata.ram,'#a855f7');
  drawChart('ch-nt',cdata.net,'#00ff88');
}

// ─── INTERNET SPEED TEST ────────────────────────────
let speedTesting=false;
async function testSpeed(){
  if(speedTesting) return;
  speedTesting=true;
  const btn=document.getElementById('spd-btn');
  btn.textContent='⏳ Aguarde ~5s...'; btn.disabled=true;
  ss('spd-st','Medindo ping e velocidade da rede...');
  ss('spd-dl','...'); ss('spd-ul','...'); ss('spd-pg','...');

  try {
    const r=await window.sv.testSpeed();
    if(r.error) throw new Error(r.error);
    ss('spd-dl',r.dl); ss('spd-ul',r.ul); ss('spd-pg',r.ping);
    ss('spd-st',`✓ Concluído — Ping: ${r.ping}ms | Down: ${r.dl} Mbps | Up: ${r.ul} Mbps`);
  } catch(e) {
    ss('spd-st','Erro: '+e.message);
    ss('spd-dl','—'); ss('spd-ul','—'); ss('spd-pg','—');
  }

  btn.textContent='▶ TESTAR NOVAMENTE'; btn.disabled=false;
  speedTesting=false;
}

// ─── FPS AO VIVO (WebGL render loop) ───────────────
let fpsHistory=[], fpsRunning=false, fpsGL=null, fpsFrame=0;

function initFpsCanvas(){
  const canvas=document.getElementById('fps-canvas');
  if(!canvas) return;

  // Redimensiona o canvas ao container
  function resize(){
    const w=canvas.parentElement.offsetWidth-24;
    canvas.width=w; canvas.style.width=w+'px';
  }
  resize();
  window.addEventListener('resize',resize);

  // WebGL context para medir FPS real do GPU
  try { fpsGL=canvas.getContext('webgl')||canvas.getContext('experimental-webgl'); } catch(e){}

  let last=performance.now(), frameCount=0;
  fpsRunning=true;

  function draw(){
    if(!fpsRunning) return;
    const now=performance.now();
    frameCount++;
    const delta=now-last;

    if(delta>=500){ // Atualiza a cada 500ms
      const fps=Math.round(frameCount/(delta/1000));
      frameCount=0; last=now;
      fpsHistory.push(fps);
      if(fpsHistory.length>120) fpsHistory.shift();

      const avg=Math.round(fpsHistory.reduce((a,b)=>a+b,0)/fpsHistory.length);
      const min=Math.min(...fpsHistory);
      const max=Math.max(...fpsHistory);
      const sorted=[...fpsHistory].sort((a,b)=>a-b);
      const p1=sorted[Math.floor(sorted.length*0.01)]||min;

      ss('fps-num',fps);
      ss('fps-avg',avg);
      ss('fps-min',min);
      ss('fps-max',max);
      ss('fps-1p',p1);
      ss('sb-fps',fps+' FPS');

      const badge=document.getElementById('fps-badge');
      if(badge){
        if(fps>=60){badge.textContent='SUAVE ≥60';badge.style.color='var(--n2)';badge.style.borderColor='rgba(0,255,136,.3)';}
        else if(fps>=30){badge.textContent='MÉDIO 30-59';badge.style.color='#ffd700';badge.style.borderColor='rgba(255,215,0,.3)';}
        else{badge.textContent='BAIXO <30';badge.style.color='var(--n3)';badge.style.borderColor='rgba(255,107,53,.3)';}
      }
      const numEl=document.getElementById('fps-num');
      if(numEl) numEl.className='fps-big '+(fps>=60?'go':fps>=30?'wa':'da');

      // Desenha gráfico FPS
      renderFpsChart(canvas);
    }

    // Renderiza algo pesado no WebGL para medir FPS real
    if(fpsGL){
      const gl=fpsGL;
      gl.clearColor(0.01,0.04,0.07,1.0);
      gl.clear(gl.COLOR_BUFFER_BIT);
      // Força o GPU a trabalhar com scissor tests para medir corretamente
      for(let i=0;i<4;i++){
        const x=Math.random()*canvas.width;
        const y=Math.random()*canvas.height;
        gl.scissor(x,y,2,2);
        gl.enable(gl.SCISSOR_TEST);
        gl.clearColor(0,i*0.07,0.1+i*0.05,1);
        gl.clear(gl.COLOR_BUFFER_BIT);
      }
      gl.disable(gl.SCISSOR_TEST);
    } else {
      // Fallback 2D
      const ctx=canvas.getContext('2d');
      if(ctx){
        ctx.fillStyle=`rgba(2,10,16,0.1)`;
        ctx.fillRect(0,0,canvas.width,canvas.height);
        // Partículas animadas para simular carga
        for(let i=0;i<8;i++){
          const x=(fpsFrame*2+i*37)%canvas.width;
          const y=Math.sin((fpsFrame+i*20)*0.05)*30+canvas.height/2;
          ctx.fillStyle=`rgba(0,212,255,${0.1+i*0.05})`;
          ctx.fillRect(x,y,2,2);
        }
      }
    }
    fpsFrame++;
    requestAnimationFrame(draw);
  }
  requestAnimationFrame(draw);
}

function renderFpsChart(canvas){
  const ctx=canvas.getContext('2d'); if(!ctx) return;
  const w=canvas.width, h=canvas.height;
  ctx.fillStyle='rgba(2,10,16,0.85)'; ctx.fillRect(0,0,w,h);
  if(fpsHistory.length<2) return;
  const maxFps=Math.max(144,Math.max(...fpsHistory));
  const step=w/(fpsHistory.length-1);
  // Zonas de cor
  [['rgba(0,255,136,0.05)',60,maxFps],['rgba(255,215,0,0.05)',30,60],['rgba(255,107,53,0.05)',0,30]].forEach(([col,lo,hi])=>{
    ctx.fillStyle=col;
    ctx.fillRect(0,h-(hi/maxFps)*h,w,(hi-lo)/maxFps*h);
  });
  // Linha 60fps
  ctx.strokeStyle='rgba(0,255,136,0.2)'; ctx.lineWidth=1; ctx.setLineDash([4,4]);
  ctx.beginPath(); ctx.moveTo(0,h-(60/maxFps)*h); ctx.lineTo(w,h-(60/maxFps)*h); ctx.stroke();
  ctx.setLineDash([]);
  // FPS line
  const grad=ctx.createLinearGradient(0,0,0,h);
  grad.addColorStop(0,'rgba(0,212,255,0.3)'); grad.addColorStop(1,'rgba(0,212,255,0)');
  ctx.beginPath(); ctx.moveTo(0,h);
  fpsHistory.forEach((v,i)=>ctx.lineTo(i*step,h-(v/maxFps)*h));
  ctx.lineTo((fpsHistory.length-1)*step,h); ctx.closePath();
  ctx.fillStyle=grad; ctx.fill();
  ctx.beginPath();
  fpsHistory.forEach((v,i)=>i===0?ctx.moveTo(0,h-(v/maxFps)*h):ctx.lineTo(i*step,h-(v/maxFps)*h));
  ctx.strokeStyle='#00d4ff'; ctx.lineWidth=1.5; ctx.stroke();
  // Label 60
  ctx.fillStyle='rgba(0,255,136,0.5)'; ctx.font='8px Share Tech Mono';
  ctx.fillText('60 FPS',4,h-(60/maxFps)*h-3);
}

// ─── BENCHMARK ──────────────────────────────────────
let benchRunning=false;
async function runBenchmark(){
  if(benchRunning) return;
  benchRunning=true;
  const btn=document.getElementById('bench-btn');
  btn.textContent='⏳ EXECUTANDO...'; btn.disabled=true;
  ss('bench-st','Rodando testes...'); ss('b-rank','');
  ['b-cpu','b-mem','b-tot'].forEach(id=>ss(id,'…'));
  ['bp-cpu','bp-mem','bp-tot'].forEach(id=>{const e=document.getElementById(id);if(e)e.style.width='0%';});

  const r=await window.sv.runBenchmark();
  animScore('b-cpu','bp-cpu',r.cpu,9999);
  animScore('b-mem','bp-mem',r.mem,9999);
  await new Promise(res=>setTimeout(res,900));
  animScore('b-tot','bp-tot',r.total,9999);

  const rank=r.total>8000?'🏆 EXCELENTE':r.total>6000?'🥇 MUITO BOM':r.total>4000?'🥈 BOM':'🥉 BÁSICO';
  ss('b-rank',rank);
  ss('bench-st',`Concluído — Total: ${r.total.toLocaleString('pt-BR')}`);
  btn.textContent='▶ EXECUTAR BENCHMARK'; btn.disabled=false;
  benchRunning=false;
}

function animScore(id,pid,val,max){
  let cur=0; const step=val/40;
  const t=setInterval(()=>{
    cur=Math.min(cur+step,val);
    ss(id,Math.round(cur).toLocaleString('pt-BR'));
    const p=document.getElementById(pid); if(p) p.style.width=(cur/max*100)+'%';
    if(cur>=val) clearInterval(t);
  },25);
}

// ─── GAMES DATABASE ─────────────────────────────────
// GPU integrada: considera VRAM como porcentagem da RAM disponível
// Requisitos ajustados para GPU integrada (Intel UHD, AMD Radeon integrada)
const GAMES=[
  {name:'Valorant',icon:'🎯',genre:'FPS Tático',
   min:{cores:2,clock:2.0,ram:4,vram:0,integrated:true},
   rec:{cores:4,clock:3.0,ram:8,vram:0,integrated:true},
   minName:'i3-4150',recName:'i5-9400F'},
  {name:'League of Legends',icon:'⚔',genre:'MOBA',
   min:{cores:2,clock:2.0,ram:4,vram:0,integrated:true},
   rec:{cores:4,clock:2.0,ram:8,vram:0,integrated:true},
   minName:'i3-3300',recName:'i5-3300'},
  {name:'CS2 (Counter-Strike 2)',icon:'💣',genre:'FPS Tático',
   min:{cores:4,clock:3.0,ram:8,vram:1.5,integrated:false},
   rec:{cores:6,clock:3.6,ram:16,vram:4,integrated:false},
   minName:'i5-8600K',recName:'i7-9700K'},
  {name:'Minecraft',icon:'⛏',genre:'Sandbox',
   min:{cores:2,clock:1.6,ram:4,vram:0,integrated:true},
   rec:{cores:4,clock:2.5,ram:8,vram:0,integrated:true},
   minName:'i3-3210',recName:'i5-4690'},
  {name:'Fortnite',icon:'🏝',genre:'Battle Royale',
   min:{cores:2,clock:2.0,ram:8,vram:0,integrated:true},
   rec:{cores:6,clock:3.2,ram:16,vram:4,integrated:false},
   minName:'i3-3225',recName:'i7-8700'},
  {name:'Roblox',icon:'🧱',genre:'Plataforma',
   min:{cores:2,clock:1.0,ram:2,vram:0,integrated:true},
   rec:{cores:4,clock:2.0,ram:4,vram:0,integrated:true},
   minName:'i5',recName:'i7'},
  {name:'Among Us',icon:'🟣',genre:'Party Game',
   min:{cores:2,clock:1.0,ram:2,vram:0,integrated:true},
   rec:{cores:4,clock:2.0,ram:4,vram:0,integrated:true},
   minName:'i5',recName:'i7'},
  {name:'Hollow Knight',icon:'🦋',genre:'Metroidvania',
   min:{cores:2,clock:1.6,ram:4,vram:0,integrated:true},
   rec:{cores:4,clock:2.5,ram:8,vram:0,integrated:true},
   minName:'i5',recName:'i7'},
  {name:'Stardew Valley',icon:'🌾',genre:'Simulação',
   min:{cores:2,clock:1.0,ram:2,vram:0,integrated:true},
   rec:{cores:4,clock:2.0,ram:4,vram:0,integrated:true},
   minName:'i5',recName:'i7'},
  {name:'Terraria',icon:'⛏',genre:'Aventura 2D',
   min:{cores:2,clock:1.0,ram:2,vram:0,integrated:true},
   rec:{cores:4,clock:2.5,ram:4,vram:0,integrated:true},
   minName:'Qualquer dual-core',recName:'i5'},
  {name:'GTA V',icon:'🚗',genre:'Mundo Aberto',
   min:{cores:4,clock:2.8,ram:8,vram:1,integrated:true},
   rec:{cores:4,clock:3.5,ram:16,vram:2,integrated:false},
   minName:'i5-3470',recName:'i5-6600K'},
  {name:'Apex Legends',icon:'🦊',genre:'Battle Royale',
   min:{cores:4,clock:2.5,ram:6,vram:1,integrated:false},
   rec:{cores:6,clock:3.4,ram:8,vram:4,integrated:false},
   minName:'i3-6300',recName:'i5-8600'},
  {name:'Overwatch 2',icon:'🦸',genre:'FPS Hero',
   min:{cores:4,clock:2.5,ram:6,vram:1,integrated:true},
   rec:{cores:6,clock:3.7,ram:8,vram:4,integrated:false},
   minName:'i3-6100',recName:'i7-8700K'},
  {name:'Cyberpunk 2077',icon:'🤖',genre:'RPG',
   min:{cores:4,clock:3.0,ram:8,vram:6,integrated:false},
   rec:{cores:6,clock:3.7,ram:12,vram:8,integrated:false},
   minName:'i7-6700K',recName:'i7-8700K'},
  {name:'Elden Ring',icon:'💍',genre:'Action RPG',
   min:{cores:6,clock:3.2,ram:12,vram:4,integrated:false},
   rec:{cores:6,clock:3.7,ram:16,vram:8,integrated:false},
   minName:'i5-8600K',recName:'i7-8700K'},
  {name:'FIFA 24',icon:'⚽',genre:'Esportes',
   min:{cores:4,clock:3.0,ram:8,vram:2,integrated:true},
   rec:{cores:4,clock:3.4,ram:16,vram:4,integrated:false},
   minName:'i5-6600K',recName:'i7-6700'},
  {name:'The Witcher 3',icon:'🗡',genre:'RPG',
   min:{cores:4,clock:3.0,ram:6,vram:2,integrated:false},
   rec:{cores:4,clock:3.4,ram:8,vram:4,integrated:false},
   minName:'i5-2500K',recName:'i7-3770'},
  {name:'Red Dead Redemption 2',icon:'🤠',genre:'Mundo Aberto',
   min:{cores:4,clock:3.0,ram:8,vram:4,integrated:false},
   rec:{cores:4,clock:3.5,ram:12,vram:6,integrated:false},
   minName:'i7-4770K',recName:'i7-4770K'},
  {name:'Hogwarts Legacy',icon:'🪄',genre:'RPG',
   min:{cores:6,clock:3.0,ram:16,vram:8,integrated:false},
   rec:{cores:6,clock:3.2,ram:16,vram:8,integrated:false},
   minName:'i7-8700',recName:'i7-8700'},
  {name:'Forza Horizon 5',icon:'🏎',genre:'Corrida',
   min:{cores:6,clock:2.8,ram:8,vram:4,integrated:false},
   rec:{cores:8,clock:3.8,ram:16,vram:8,integrated:false},
   minName:'i5-8400',recName:'i7-10700K'},
  {name:'Call of Duty Warzone',icon:'🔫',genre:'Battle Royale',
   min:{cores:4,clock:3.0,ram:8,vram:2,integrated:false},
   rec:{cores:6,clock:3.7,ram:16,vram:8,integrated:false},
   minName:'i3-4340',recName:'i7-8700K'},
  {name:'Hades',icon:'💀',genre:'Roguelike',
   min:{cores:4,clock:2.0,ram:8,vram:1,integrated:true},
   rec:{cores:4,clock:3.0,ram:16,vram:2,integrated:true},
   minName:'i5-2400',recName:'i7-4000'},
  {name:'Palworld',icon:'🐉',genre:'Survival',
   min:{cores:4,clock:3.0,ram:16,vram:4,integrated:false},
   rec:{cores:8,clock:3.6,ram:32,vram:8,integrated:false},
   minName:'i5-4430',recName:'i9-9900K'},
  {name:'Baldur\'s Gate 3',icon:'🎲',genre:'RPG',
   min:{cores:6,clock:3.0,ram:8,vram:6,integrated:false},
   rec:{cores:6,clock:3.7,ram:16,vram:8,integrated:false},
   minName:'i7-8700K',recName:'i7-8700K'},
  {name:'Starfield',icon:'🚀',genre:'RPG Sci-Fi',
   min:{cores:6,clock:3.0,ram:16,vram:8,integrated:false},
   rec:{cores:6,clock:3.5,ram:16,vram:8,integrated:false},
   minName:'i7-6800K',recName:'i7-7800X'},
];

const POPULAR=['Valorant','League of Legends','Minecraft','Roblox','Fortnite','CS2 (Counter-Strike 2)','GTA V','Overwatch 2'];

let hwCpu=null, hwRamGB=0, hwGpus=[], hwHasIntegrated=false, hwVramGB=0;

function initGames(cpu,mem,gpus){
  hwCpu=cpu;
  hwRamGB=mem.total/1e9;
  hwGpus=gpus;
  hwHasIntegrated=gpus.some(g=>g.vramDynamic);
  // VRAM: usa dedicada se tiver, senão estima ~25% da RAM como VRAM integrada
  const dedicated=gpus.find(g=>!g.vramDynamic);
  hwVramGB=dedicated?dedicated.vram/1024:(hwRamGB*0.25);

  const chips=document.getElementById('chips');
  if(chips) chips.innerHTML=POPULAR.map(n=>`<span class="chip" onclick="quickSearch('${n}')">${n}</span>`).join('');
}

function quickSearch(name){ document.getElementById('gi').value=name; searchGame(name); }
function clearGame(){ document.getElementById('gi').value=''; document.getElementById('gm-res').innerHTML=''; }

function searchGame(q){
  q=(q||'').trim().toLowerCase();
  const area=document.getElementById('gm-res');
  if(!q){ area.innerHTML=''; return; }
  const matches=GAMES.filter(g=>g.name.toLowerCase().includes(q));
  if(!matches.length){
    area.innerHTML=`<div style="text-align:center;padding:40px;color:var(--t3);font-family:var(--fm);font-size:11px">
      <div style="font-size:28px;margin-bottom:8px">🔍</div>"${q}" não encontrado</div>`;
    return;
  }
  area.innerHTML=matches.slice(0,5).map(g=>renderGame(g)).join('');
}

function checkGame(game){
  if(!hwCpu) return {verdict:'wa',label:'Hardware não detectado'};
  const cores=hwCpu.cores||4;
  const clock=hwCpu.speedMax||hwCpu.speed||2.0;
  const ram=hwRamGB;
  const vram=hwVramGB;
  const hasIntegrated=hwHasIntegrated;

  // Verifica mínimo
  const minOk=
    cores>=game.min.cores &&
    clock>=game.min.clock &&
    ram>=game.min.ram &&
    (game.min.integrated ? true : vram>=game.min.vram) &&
    (game.min.integrated ? true : !hasIntegrated||vram>=1);

  // Verifica recomendado
  const recOk=
    cores>=game.rec.cores &&
    clock>=game.rec.clock &&
    ram>=game.rec.ram &&
    (game.rec.integrated ? vram>=game.rec.vram*0.5 : vram>=game.rec.vram);

  const details={
    cores:{have:cores,need:game.min.cores,recNeed:game.rec.cores,ok:cores>=game.min.cores,recOk:cores>=game.rec.cores},
    clock:{have:clock.toFixed(1),need:game.min.clock,recNeed:game.rec.clock,ok:clock>=game.min.clock,recOk:clock>=game.rec.clock},
    ram:{have:ram.toFixed(1),need:game.min.ram,recNeed:game.rec.ram,ok:ram>=game.min.ram,recOk:ram>=game.rec.ram},
    vram:{have:vram.toFixed(1),need:game.min.vram,recNeed:game.rec.vram,ok:game.min.integrated||vram>=game.min.vram,recOk:game.rec.integrated||vram>=game.rec.vram},
  };

  return {
    verdict:recOk?'y':minOk?'w':'n',
    label:recOk?'✓ RODA BEM':minOk?'⚠ RODA (MÍNIMO)':'✕ NÃO RODA',
    details
  };
}

function fpsEst(game,compat){
  if(compat.verdict==='n') return null;
  const isMed=compat.verdict==='w';
  // Base FPS dependendo se tem GPU integrada e requisitos do jogo
  const base=game.min.integrated?(isMed?45:75):(isMed?28:65);
  return{
    low:  Math.min(999,Math.round(base*1.8)),
    med:  Math.min(999,Math.round(base*1.2)),
    high: Math.min(999,Math.round(base*0.7)),
    ultra:Math.min(999,Math.round(base*0.4))
  };
}

function reqRow(label,have,need,recNeed,ok,recOk){
  const cls=recOk?'go':ok?'wa':'da';
  const icon=recOk?'✓':ok?'~':'✕';
  return `<div class="sr"><span class="sl">${label}</span><span class="sv ${cls}">${icon} ${have} / mín:${need}</span></div>`;
}

function renderGame(game){
  const c=checkGame(game);
  const fps=fpsEst(game,c);
  const d=c.details;
  const vcls={'y':'vy','w':'vw','n':'vn'}[c.verdict];

  const fpsBar=(lbl,val,color)=>val==null?'':
    `<div class="fr"><span class="fql">${lbl}</span>
    <div class="ftr"><div class="ff" style="width:${Math.min(100,val/144*100)}%;background:${color}"></div></div>
    <span class="fn ${val>=60?'go':val>=30?'wa':'da'}">${val} FPS</span></div>`;

  return `<div class="gc">
    <div class="gh">
      <span class="gic">${game.icon}</span>
      <div><div class="gnm">${game.name}</div><div class="ggn">${game.genre}</div></div>
      <div class="gv ${vcls}">${c.label}</div>
    </div>
    <div class="rg">
      <div class="rb"><div class="rt">SEU HARDWARE</div>
        ${reqRow('Núcleos',d.cores.have+'t',d.cores.need,d.cores.recNeed,d.cores.ok,d.cores.recOk)}
        ${reqRow('Clock',d.clock.have+' GHz',d.clock.need,d.clock.recNeed,d.clock.ok,d.clock.recOk)}
        ${reqRow('RAM',d.ram.have+' GB',d.ram.need+'GB',d.ram.recNeed+'GB',d.ram.ok,d.ram.recOk)}
        ${reqRow('GPU/VRAM',d.vram.have+' GB',d.vram.need+'GB',d.vram.recNeed+'GB',d.vram.ok,d.vram.recOk)}
        <div class="sr"><span class="sl">GPU</span><span class="sv ${hwHasIntegrated?'wa':'go'}">${hwHasIntegrated?'Integrada':'Dedicada'}</span></div>
      </div>
      <div class="rb"><div class="rt">REQUISITOS</div>
        ${sr('CPU Mín',game.minName)}
        ${sr('CPU Rec',game.recName)}
        ${sr('RAM Mín',game.min.ram+' GB')}
        ${sr('RAM Rec',game.rec.ram+' GB')}
        ${sr('GPU',game.min.integrated?'Integrada OK':'Dedicada recomendada',game.min.integrated?'go':'wa')}
      </div>
    </div>
    ${fps?`<div class="fe">
      <div class="ft">ESTIMATIVA DE FPS (com seu hardware)</div>
      <div class="fps-bars">
        ${fpsBar('Baixo',fps.low,'#00ff88')}
        ${fpsBar('Médio',fps.med,'#00d4ff')}
        ${fpsBar('Alto',fps.high,'#a855f7')}
        ${fpsBar('Ultra',fps.ultra,'#ff6b35')}
      </div>
    </div>`:
    `<div class="fe" style="text-align:center;color:var(--n3);font-size:11px;font-family:var(--fm)">
      Hardware abaixo dos requisitos mínimos para este jogo
    </div>`}
  </div>`;
}

// ─── SHARE ──────────────────────────────────────────
function openShare(){
  if(!staticData) return;
  const {cpu,mem,os,gpu}=staticData;
  const g=gpu.controllers?.[0];
  const txt=`
╔══════════════════════════════════════╗
║    SPECVIEW v4.0 — SPECS DO PC      ║
╠══════════════════════════════════════╣
║ CPU:  ${(cpu.manufacturer+' '+cpu.brand).substring(0,36).padEnd(36)} ║
║ Cor:  ${String(cpu.cores).padEnd(36)} ║
║ RAM:  ${(gb(mem.total)+' GB').padEnd(36)} ║
║ GPU:  ${(g?.model||'N/A').substring(0,36).padEnd(36)} ║
║ VRAM: ${(g?.vram?g.vram+' MB':g?.vramDynamic?'Integrada':'N/A').padEnd(36)} ║
║ OS:   ${(os.distro+' '+os.release).substring(0,36).padEnd(36)} ║
║ Arq:  ${os.arch.padEnd(36)} ║
╚══════════════════════════════════════╝
${new Date().toLocaleString('pt-BR')} — SpecView v4.0`.trim();
  document.getElementById('share-txt').textContent=txt;
  document.getElementById('md').classList.add('on');
}
async function copyShare(){
  await navigator.clipboard.writeText(document.getElementById('share-txt').textContent);
  const btn=event.target; btn.textContent='✓ Copiado!';
  setTimeout(()=>btn.textContent='📋 Copiar',2000);
}
function closeMd(){ document.getElementById('md').classList.remove('on'); }

// ─── CLOCK ──────────────────────────────────────────
function tick(){ ss('sb-clk',new Date().toLocaleTimeString('pt-BR')); }

// ─── INIT ────────────────────────────────────────────
async function init(){
  await loadStatic();
  await updateDynamic();
  setInterval(updateDynamic,2000);
  setInterval(tick,1000);
  tick();
}

document.getElementById('md').addEventListener('click',e=>{if(e.target===document.getElementById('md')) closeMd();});
init();
