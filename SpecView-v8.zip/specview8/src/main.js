const { app, BrowserWindow, ipcMain, Tray, Menu, nativeImage } = require('electron');
const path = require('path');
const { execSync } = require('child_process');

let mainWindow, tray;
let isQuitting = false;
let si = null;

function getSI() {
  if (!si) si = require('systeminformation');
  return si;
}

// ── TEMPERATURA VIA WMI (fallback robusto para Windows) ─────────────
function getTempWMI() {
  try {
    const raw = execSync(
      'powershell -NoProfile -Command "Get-WmiObject MSAcpi_ThermalZoneTemperature -Namespace root/wmi | Select-Object -ExpandProperty CurrentTemperature"',
      { timeout: 5000, windowsHide: true }
    ).toString().trim();
    const lines = raw.split('\n').map(l => l.trim()).filter(l => /^\d+$/.test(l));
    if (lines.length > 0) {
      const temps = lines.map(v => Math.round((parseInt(v) / 10) - 273.15)).filter(t => t > 0 && t < 120);
      if (temps.length > 0) {
        return {
          main: Math.round(temps.reduce((a, b) => a + b, 0) / temps.length),
          cores: temps,
          gpu: -1,
          source: 'WMI'
        };
      }
    }
  } catch (_) {}
  return null;
}

// ── TRAY ────────────────────────────────────────────────────────────
function createTray() {
  let icon;
  try {
    icon = nativeImage.createFromPath(path.join(__dirname, '../assets/icon.ico'));
    if (icon.isEmpty()) icon = nativeImage.createEmpty();
    else icon = icon.resize({ width: 16, height: 16 });
  } catch (_) { icon = nativeImage.createEmpty(); }

  tray = new Tray(icon);
  tray.setToolTip('SpecView - Monitor de Hardware');
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Abrir SpecView', click: () => { mainWindow.show(); mainWindow.focus(); } },
    { type: 'separator' },
    { label: 'Sair', click: () => { isQuitting = true; app.quit(); } }
  ]));
  tray.on('click', () => mainWindow.isVisible() ? mainWindow.hide() : (mainWindow.show(), mainWindow.focus()));
  tray.on('double-click', () => { mainWindow.show(); mainWindow.focus(); });
}

// ── WINDOW ──────────────────────────────────────────────────────────
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280, height: 860, minWidth: 960, minHeight: 640,
    frame: false, backgroundColor: '#030b12',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    icon: path.join(__dirname, '../assets/icon.ico'),
    show: false
  });
  mainWindow.loadFile(path.join(__dirname, 'index.html'));
  mainWindow.setMenuBarVisibility(false);
  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.on('close', e => {
    if (!isQuitting) {
      e.preventDefault();
      mainWindow.hide();
      try {
        tray.displayBalloon({
          title: 'SpecView rodando na bandeja',
          content: 'Clique no icone para reabrir. Clique direito > Sair para fechar.',
          iconType: 'info'
        });
      } catch (_) {}
    }
  });
}

app.whenReady().then(() => { createTray(); createWindow(); });
app.on('before-quit', () => { isQuitting = true; });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

const withTimeout = (p, ms, fb) => Promise.race([p, new Promise(r => setTimeout(() => r(fb), ms))]);

// ── STATIC ──────────────────────────────────────────────────────────
ipcMain.handle('get-static', async () => {
  try {
    const lib = getSI();
    const [cpu, mem, os, gpu, disk, mb, bios] = await Promise.all([
      withTimeout(lib.cpu(),        6000, {}),
      withTimeout(lib.mem(),        6000, {}),
      withTimeout(lib.osInfo(),     6000, {}),
      withTimeout(lib.graphics(),   6000, { controllers: [] }),
      withTimeout(lib.diskLayout(), 6000, []),
      withTimeout(lib.baseboard(),  6000, {}),
      withTimeout(lib.bios(),       6000, {})
    ]);
    return { cpu, mem, os, gpu, disk, mb, bios };
  } catch (e) { return { error: e.message }; }
});

// ── DYNAMIC ─────────────────────────────────────────────────────────
ipcMain.handle('get-dynamic', async () => {
  try {
    const lib = getSI();
    const [cpuLoad, mem, cpuTempSI, netStats, processes] = await Promise.all([
      withTimeout(lib.currentLoad(),    3000, { currentLoad: 0, cpus: [] }),
      withTimeout(lib.mem(),            3000, {}),
      withTimeout(lib.cpuTemperature(), 4000, { main: -1, cores: [], gpu: -1 }),
      withTimeout(lib.networkStats(),   3000, [{}]),
      withTimeout(lib.processes(),      3000, { list: [] })
    ]);

    // Se systeminformation nao retornou temperatura, tenta WMI
    let cpuTemp = cpuTempSI;
    const siHasTemp = cpuTempSI && (cpuTempSI.main > 0 || (cpuTempSI.cores || []).some(t => t > 0));
    if (!siHasTemp) {
      const wmiTemp = getTempWMI();
      if (wmiTemp) cpuTemp = wmiTemp;
    }

    return { cpuLoad, mem, cpuTemp, netStats, processes };
  } catch (e) { return { error: e.message }; }
});

// ── SPEED TEST ──────────────────────────────────────────────────────
ipcMain.handle('test-speed', async () => {
  try {
    const lib = getSI();

    // Ping
    const pings = [];
    for (let i = 0; i < 4; i++) {
      try {
        const p = await withTimeout(lib.inetLatency('8.8.8.8'), 4000, -1);
        if (p > 0) pings.push(p);
        await new Promise(r => setTimeout(r, 200));
      } catch (_) {}
    }
    const ping = pings.length ? Math.round(pings.reduce((a, b) => a + b, 0) / pings.length) : 999;

    // Velocidade: mede bytes em 4 segundos
    const snap1 = await withTimeout(lib.networkStats(), 3000, null);
    if (!snap1 || !snap1[0]) return { ping, dl: '0.0', ul: '0.0' };

    await new Promise(r => setTimeout(r, 4000));

    const snap2 = await withTimeout(lib.networkStats(), 3000, null);
    if (!snap2 || !snap2[0]) return { ping, dl: '0.0', ul: '0.0' };

    // Pega a interface com mais trafego
    let bestDl = 0, bestUl = 0;
    for (let i = 0; i < Math.min(snap1.length, snap2.length); i++) {
      const s1 = snap1[i], s2 = snap2[i];
      if (!s1 || !s2 || s1.iface === 'lo') continue;
      const dl = Math.max(0, (s2.rx_bytes - s1.rx_bytes) / 4 / 1e6 * 8);
      const ul = Math.max(0, (s2.tx_bytes - s1.tx_bytes) / 4 / 1e6 * 8);
      if (dl > bestDl) bestDl = dl;
      if (ul > bestUl) bestUl = ul;
    }

    return { ping, dl: bestDl.toFixed(1), ul: bestUl.toFixed(1) };
  } catch (e) { return { error: e.message, ping: 999, dl: '0.0', ul: '0.0' }; }
});

// ── BENCHMARK ───────────────────────────────────────────────────────
ipcMain.handle('run-benchmark', async () => {
  const t0 = Date.now();
  let s = 0;
  for (let i = 0; i < 8000000; i++) s += Math.sqrt(i) * Math.sin(i);
  const cpu = Math.round(Math.max(1000, Math.min(9999, 2e9 / (Date.now() - t0))));

  const t1 = Date.now();
  const arr = new Float64Array(2000000);
  for (let i = 0; i < arr.length; i++) arr[i] = Math.random();
  arr.sort();
  const mem = Math.round(Math.max(1000, Math.min(9999, 1e8 / (Date.now() - t1))));

  return { cpu, mem, total: Math.round(cpu * 0.6 + mem * 0.4) };
});

// ── WINDOW CONTROLS ─────────────────────────────────────────────────
ipcMain.on('win-min',  () => mainWindow.minimize());
ipcMain.on('win-max',  () => mainWindow.isMaximized() ? mainWindow.unmaximize() : mainWindow.maximize());
ipcMain.on('win-tray', () => mainWindow.hide());
ipcMain.on('win-quit', () => { isQuitting = true; app.quit(); });
