const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('sv', {
  getStatic:     () => ipcRenderer.invoke('get-static'),
  getDynamic:    () => ipcRenderer.invoke('get-dynamic'),
  testSpeed:     () => ipcRenderer.invoke('test-speed'),
  runBenchmark:  () => ipcRenderer.invoke('run-benchmark'),
  minimize: () => ipcRenderer.send('win-min'),
  maximize: () => ipcRenderer.send('win-max'),
  toTray:   () => ipcRenderer.send('win-tray'),
  quit:     () => ipcRenderer.send('win-quit'),
});
