@echo off
cd /d "%~dp0"
if exist launcher.vbs (
    wscript //nologo launcher.vbs
) else (
    npm start
)
