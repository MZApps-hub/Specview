@echo off
title SpecView - Compilando EXE...
color 0E
cls

echo.
echo  ================================
echo   SPECVIEW - Gerar .EXE
echo  ================================
echo.
echo  Vai gerar na pasta dist\:
echo   - SpecView Setup.exe     (instalador)
echo   - SpecView-Portatil.exe  (portatil)
echo.
echo  IMPORTANTE: Nao feche esta janela!
echo  Primeira vez pode demorar 15-20 minutos.
echo  O progresso aparece abaixo em tempo real.
echo.
pause

cd /d "%~dp0"

echo.
echo [1/3] Instalando dependencias...
call npm install
if %errorlevel% neq 0 (
    echo.
    echo ERRO no npm install.
    echo Execute instalar.bat primeiro.
    pause
    exit /b 1
)
echo [OK] Dependencias prontas!
echo.

echo [2/3] Verificando electron-builder...
call npm list electron-builder >nul 2>&1
if %errorlevel% neq 0 (
    echo Instalando electron-builder...
    call npm install electron-builder --save-dev
)
echo [OK] electron-builder pronto!
echo.

echo [3/3] Compilando para Windows x64...
echo (O download do Electron pode demorar - aguarde!)
echo.

call node_modules\.bin\electron-builder --win nsis portable --x64

if %errorlevel% neq 0 (
    echo.
    echo ================================
    echo  ERRO na compilacao!
    echo ================================
    echo.
    echo Tente:
    echo  1. Feche e abra como Administrador
    echo  2. Desative antivirus temporariamente
    echo  3. Verifique conexao com a internet
    echo.
    pause
    exit /b 1
)

echo.
echo ================================
echo  SUCESSO! EXE gerado em dist\
echo ================================
echo.
set /p AB=Abrir pasta dist\? (S/N): 
if /i "%AB%"=="S" explorer "%~dp0dist"
pause
