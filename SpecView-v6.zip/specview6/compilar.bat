@echo off
title SpecView - Compilar EXE
color 0E
cls

echo.
echo  ================================
echo   SPECVIEW - Gerar .EXE
echo  ================================
echo.
echo  Vai gerar:
echo   - SpecView Setup.exe  (instalador)
echo   - SpecView-Portatil.exe  (portatil)
echo.
echo  Pode demorar 10-20 minutos.
echo  Nao feche esta janela!
echo.
pause

cd /d "%~dp0"
npm install
if %errorlevel% neq 0 (
    echo ERRO: Execute instalar.bat primeiro.
    pause
    exit /b 1
)

echo.
echo Compilando (aguarde)...
echo.
npx electron-builder --win nsis portable --x64

if %errorlevel% neq 0 (
    echo.
    echo ERRO na compilacao. Tente rodar como Administrador.
    pause
    exit /b 1
)

echo.
echo ================================
echo  EXE gerado na pasta dist\
echo ================================
echo.

set /p AB=Abrir pasta dist? (S/N): 
if /i "%AB%"=="S" explorer dist

pause
