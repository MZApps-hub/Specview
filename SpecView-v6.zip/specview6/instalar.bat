@echo off
title SpecView v4 - Instalador
color 0B
cls

echo.
echo  ================================
echo   SPECVIEW v4.0 - Hardware Monitor
echo  ================================
echo.

echo [1/3] Verificando Node.js...
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Node.js nao encontrado. Abrindo download...
    start https://nodejs.org/dist/v20.10.0/node-v20.10.0-x64.msi
    echo Instale o Node.js e execute este arquivo novamente.
    pause
    exit /b 1
)
echo [OK] Node.js encontrado!
echo.

echo [2/3] Instalando dependencias (aguarde 2-5 min)...
cd /d "%~dp0"
npm install
if %errorlevel% neq 0 (
    echo ERRO ao instalar. Tente rodar como Administrador.
    pause
    exit /b 1
)
echo [OK] Dependencias instaladas!
echo.

echo [3/3] Criando atalho na Area de Trabalho...
set PASTA=%~dp0

echo Set WshShell = CreateObject("WScript.Shell") > "%PASTA%launcher.vbs"
echo WshShell.CurrentDirectory = "%PASTA%" >> "%PASTA%launcher.vbs"
echo WshShell.Run "npm start", 0, False >> "%PASTA%launcher.vbs"

powershell -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut('%USERPROFILE%\Desktop\SpecView.lnk');$s.TargetPath='wscript.exe';$s.Arguments='\"%PASTA%launcher.vbs\"';$s.WorkingDirectory='%PASTA%';$s.IconLocation='%PASTA%assets\icon.ico';$s.Description='SpecView - Monitor de Hardware';$s.Save()"

if exist "%USERPROFILE%\Desktop\SpecView.lnk" (
    echo [OK] Atalho criado na Area de Trabalho!
) else (
    echo [AVISO] Atalho nao criado. Use iniciar.bat para abrir.
)

echo.
echo ================================
echo  INSTALACAO CONCLUIDA!
echo ================================
echo.
echo  Proximas vezes: clique em "SpecView" na Area de Trabalho
echo  Sem janela preta - abre direto como Discord!
echo.
echo  Para temperatura real: clique direito em iniciar.bat
echo  e escolha "Executar como administrador"
echo.

set /p ABRIR=Abrir o SpecView agora? (S/N): 
if /i "%ABRIR%"=="S" (
    wscript "%PASTA%launcher.vbs"
)

pause
