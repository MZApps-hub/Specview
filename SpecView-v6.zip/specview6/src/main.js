const { app, BrowserWindow, ipcMain, Tray, Menu, nativeImage } = require('electron');
const path = require('path');

let mainWindow, tray;
let isQuitting = false;
let si = null;

// Carrega systeminformation de forma lazy para nao travar o start
function getSI() {
  if (!si) si = require('systeminformation');
  return si;
}

function createTray() {
  let icon;
  try {
    icon = nativeImage.createFromPath(path.join(__dirname, '../assets/icon.ico'));
    if (icon.isEmpty()) icon = nativeImage.createEmpty();
    else icon = icon.resize({ width: 16, height: 16 });
  } catch (e) { icon = nativeImage.createEmpty(); }

  tray = new Tray(icon);
  tray.setToolTip('SpecView - Monitor de Hardware');
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Abrir SpecView', click: () => { mainWindow.show(); mainWindow.focus(); } },
    { type: 'separator' },
    { label: 'Sair', click: () => { isQuitting = true; app.quit(); } }
  ]));
  tray.on('click', () => mainWindow.isVisible() ? mainWindow.hide() : (mainWindow.show(), mainWindow.focus()));
  tray.on('double-click', () => { mainWindow.show(); mainWindow.focus(); });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280, height: 860, minWidth: 960, minHeight: 640,
    frame: false, backgroundColor: '#030b12',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    icon: path.join(__dirname, '../assets/icon.ico'),
    show: false
  });
  mainWindow.loadFile(path.join(__dirname, 'index.html'));
  mainWindow.setMenuBarVisibility(false);
  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.on('close', e => {
    if (!isQuitting) {
      e.preventDefault();
      mainWindow.hide();
      try {
        tray.displayBalloon({
          title: 'SpecView rodando na bandeja',
          content: 'Clique no icone para reabrir.',
          iconType: 'info'
        });
      } catch (_) {}
    }
  });
}

app.whenReady().then(() => {
  createTray();
  createWindow();
});
app.on('before-quit', () => { isQuitting = true; });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

// Helper com timeout para nao travar
async function withTimeout(promise, ms, fallback) {
  return Promise.race([
    promise,
    new Promise(r => setTimeout(() => r(fallback), ms))
  ]);
}

// STATIC - carrega com timeout individual por item
ipcMain.handle('get-static', async () => {
  try {
    const lib = getSI();
    const [cpu, mem, os, gpu, disk, mb, bios] = await Promise.all([
      withTimeout(lib.cpu(), 5000, {}),
      withTimeout(lib.mem(), 5000, {}),
      withTimeout(lib.osInfo(), 5000, {}),
      withTimeout(lib.graphics(), 5000, { controllers: [] }),
      withTimeout(lib.diskLayout(), 5000, []),
      withTimeout(lib.baseboard(), 5000, {}),
      withTimeout(lib.bios(), 5000, {})
    ]);
    return { cpu, mem, os, gpu, disk, mb, bios };
  } catch (e) { return { error: e.message }; }
});

// DYNAMIC - timeout de 3s por item
ipcMain.handle('get-dynamic', async () => {
  try {
    const lib = getSI();
    const [cpuLoad, mem, cpuTemp, netStats, processes] = await Promise.all([
      withTimeout(lib.currentLoad(), 3000, { currentLoad: 0, cpus: [] }),
      withTimeout(lib.mem(), 3000, {}),
      withTimeout(lib.cpuTemperature(), 3000, { main: -1, cores: [], gpu: -1 }),
      withTimeout(lib.networkStats(), 3000, [{}]),
      withTimeout(lib.processes(), 3000, { list: [] })
    ]);
    return { cpuLoad, mem, cpuTemp, netStats, processes };
  } catch (e) { return { error: e.message }; }
});

// SPEED TEST
ipcMain.handle('test-speed', async () => {
  try {
    const lib = getSI();
    const pings = [];
    for (let i = 0; i < 4; i++) {
      const p = await withTimeout(lib.inetLatency('8.8.8.8'), 3000, -1);
      if (p > 0) pings.push(p);
    }
    const ping = pings.length ? Math.round(pings.reduce((a, b) => a + b, 0) / pings.length) : 999;
    const before = await withTimeout(lib.networkStats(), 2000, [{}]);
    await new Promise(r => setTimeout(r, 3000));
    const after = await withTimeout(lib.networkStats(), 2000, [{}]);
    let dl = 0, ul = 0;
    if (before[0] && after[0] && before[0].rx_bytes != null) {
      dl = Math.max(0, (after[0].rx_bytes - before[0].rx_bytes) / 3 / 1e6 * 8);
      ul = Math.max(0, (after[0].tx_bytes - before[0].tx_bytes) / 3 / 1e6 * 8);
    }
    return { ping, dl: dl.toFixed(1), ul: ul.toFixed(1) };
  } catch (e) { return { error: e.message }; }
});

// BENCHMARK
ipcMain.handle('run-benchmark', async () => {
  const t0 = Date.now();
  let s = 0;
  for (let i = 0; i < 8000000; i++) s += Math.sqrt(i) * Math.sin(i);
  const cpu = Math.round(Math.max(1000, Math.min(9999, 2e9 / (Date.now() - t0))));

  const t1 = Date.now();
  const arr = new Float64Array(2000000);
  for (let i = 0; i < arr.length; i++) arr[i] = Math.random();
  arr.sort();
  const mem = Math.round(Math.max(1000, Math.min(9999, 1e8 / (Date.now() - t1))));

  return { cpu, mem, total: Math.round(cpu * 0.6 + mem * 0.4) };
});

// WINDOW CONTROLS
ipcMain.on('win-min',  () => mainWindow.minimize());
ipcMain.on('win-max',  () => mainWindow.isMaximized() ? mainWindow.unmaximize() : mainWindow.maximize());
ipcMain.on('win-tray', () => mainWindow.hide());
ipcMain.on('win-quit', () => { isQuitting = true; app.quit(); });
