@echo off
title SpecView - Compilador EXE
color 0E
cls

echo.
echo  ================================
echo   SPECVIEW - Gerar EXE
echo  ================================
echo.
echo  Isso vai gerar:
echo   - SpecView Setup.exe  (instalador)
echo   - SpecView-Portatil.exe  (portatil)
echo.
echo  Pode demorar 10-20 minutos.
echo  Nao feche esta janela!
echo.
pause

cd /d "%~dp0"

echo [1/2] Instalando dependencias...
npm install
if %errorlevel% neq 0 (
    echo ERRO: Execute instalar.bat primeiro.
    pause
    exit /b 1
)

echo.
echo [2/2] Compilando EXE (aguarde)...
echo.
npx electron-builder --win nsis portable --x64
if %errorlevel% neq 0 (
    echo.
    echo ERRO na compilacao. Tente rodar como Administrador.
    pause
    exit /b 1
)

echo.
echo ================================
echo  EXE gerado na pasta dist\
echo ================================
echo.
echo  dist\SpecView Setup X.X.X.exe  - Instalador
echo  dist\SpecView-Portatil.exe     - Portatil
echo.

set /p ABRIR=Abrir pasta dist? (S/N): 
if /i "%ABRIR%"=="S" explorer dist

pause
