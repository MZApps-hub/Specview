@echo off
title SpecView - Instalador
color 0B
cls

echo.
echo  ================================
echo   SPECVIEW - Monitor de Hardware
echo  ================================
echo.

echo [1/3] Verificando Node.js...
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  Node.js nao encontrado!
    echo  Abrindo pagina de download...
    echo  Instale o Node.js e execute este arquivo novamente.
    echo.
    start https://nodejs.org/dist/v20.10.0/node-v20.10.0-x64.msi
    echo Pressione qualquer tecla apos instalar o Node.js...
    pause >nul
    node --version >nul 2>&1
    if %errorlevel% neq 0 (
        echo ERRO: Node.js ainda nao detectado. Reinicie e tente novamente.
        pause
        exit /b 1
    )
)
echo [OK] Node.js encontrado!
echo.

echo [2/3] Instalando dependencias (aguarde 2-5 minutos)...
cd /d "%~dp0"
npm install
if %errorlevel% neq 0 (
    echo.
    echo ERRO ao instalar dependencias.
    echo Tente rodar como Administrador.
    pause
    exit /b 1
)
echo [OK] Dependencias instaladas!
echo.

echo [3/3] Criando atalho na Area de Trabalho...
set PASTA=%~dp0

:: Cria o VBS launcher (abre sem janela preta)
echo Set WshShell = CreateObject("WScript.Shell") > "%PASTA%launcher.vbs"
echo WshShell.CurrentDirectory = "%PASTA%" >> "%PASTA%launcher.vbs"
echo WshShell.Run "npm start", 0, False >> "%PASTA%launcher.vbs"

:: Cria o atalho .lnk na Area de Trabalho
powershell -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut('%USERPROFILE%\Desktop\SpecView.lnk');$s.TargetPath='wscript.exe';$s.Arguments='\"%PASTA%launcher.vbs\"';$s.WorkingDirectory='%PASTA%';$s.IconLocation='%PASTA%assets\icon.ico';$s.Description='SpecView - Monitor de Hardware';$s.Save()"

if exist "%USERPROFILE%\Desktop\SpecView.lnk" (
    echo [OK] Atalho criado na Area de Trabalho!
) else (
    echo [AVISO] Nao foi possivel criar atalho. Use iniciar.bat para abrir.
)
echo.

echo ================================
echo  SUCESSO! SpecView instalado!
echo ================================
echo.
echo  Proximo uso: clique em "SpecView" na Area de Trabalho
echo  Ou execute iniciar.bat nesta pasta
echo.

set /p ABRIR=Deseja abrir o SpecView agora? (S/N): 
if /i "%ABRIR%"=="S" npm start

pause
