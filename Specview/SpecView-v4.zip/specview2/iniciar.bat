@echo off
title SpecView
cd /d "%~dp0"
npm start
