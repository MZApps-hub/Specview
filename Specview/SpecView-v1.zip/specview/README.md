# SpecView Desktop v2.0
> Monitor de Hardware para Windows — Dados reais via Electron + systeminformation

## 🚀 Como instalar e rodar

### Pré-requisitos
- [Node.js](https://nodejs.org) (versão 18 ou superior) — baixe e instale
- Windows 10 ou 11

### Passos

1. **Extraia a pasta** `specview` em qualquer lugar do seu PC

2. **Abra o Terminal** (PowerShell ou CMD) dentro da pasta:
   ```
   cd caminho\para\specview
   ```

3. **Instale as dependências** (só na primeira vez):
   ```
   npm install
   ```

4. **Rode o app:**
   ```
   npm start
   ```

---

## 🌡️ Temperatura real
Para leitura de temperatura da CPU/GPU, rode o app **como Administrador**:
- Clique com botão direito no PowerShell → "Executar como administrador"
- Navegue até a pasta e rode `npm start`

---

## 📦 O que o app detecta (via systeminformation)

| Componente | Dados |
|---|---|
| CPU | Modelo, fabricante, núcleos, cache, velocidade, virtualização |
| RAM | Total, usado, livre, swap, cache |
| GPU | Modelo, VRAM, driver, resolução |
| Disco | Modelo, tamanho, tipo (SSD/HDD), interface |
| Placa-mãe | Fabricante, modelo, versão, BIOS |
| Temperatura | CPU por core, GPU (requer admin) |
| Rede | Interface, bytes enviados/recebidos, velocidade |
| Processos | Top processos por uso de CPU |

---

## ⚡ Benchmark
Testa CPU e Memória nativamente via Node.js:
- **CPU Score**: Operações matemáticas intensivas (5M iterações)
- **MEM Score**: Alocação e ordenação de arrays grandes (1M elementos)
- **Score**: 1.000 (básico) → 9.999 (excelente)

---

## 🛠️ Tecnologias
- **Electron** — janela nativa Windows
- **systeminformation** — leitura real de hardware
- HTML/CSS/JS — interface visual

## 📋 Compartilhar / Exportar
- **Compartilhar**: gera texto formatado para copiar
- **Exportar PDF**: usa a função de impressão do Electron (Ctrl+P)
