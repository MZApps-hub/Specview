const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('specview', {
  getStaticInfo:  () => ipcRenderer.invoke('get-static-info'),
  getDynamicInfo: () => ipcRenderer.invoke('get-dynamic-info'),
  runBenchmark:   () => ipcRenderer.invoke('run-benchmark'),
  minimize: () => ipcRenderer.send('window-minimize'),
  maximize: () => ipcRenderer.send('window-maximize'),
  hideToTray: () => ipcRenderer.send('window-hide'),
  quit:     () => ipcRenderer.send('window-close'),
});
