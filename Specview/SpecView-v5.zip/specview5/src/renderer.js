// ═══════════════════════════════════════════════
// SPECVIEW v3.0 — RENDERER
// ═══════════════════════════════════════════════

let staticData = null;
const chartData = { cpu: new Array(60).fill(0), ram: new Array(60).fill(0), net: new Array(60).fill(0) };

// ─── UTILS ───────────────────────────────────
const gb  = b => (b / 1e9).toFixed(1);
const mb2 = b => (b / 1e6).toFixed(2);
const pct = (v, t) => t > 0 ? ((v / t) * 100).toFixed(1) : '0';
const tempColor = t => !t || t <= 0 ? 'warn' : t < 60 ? 'good' : t < 80 ? 'warn' : 'danger';
const sr  = (l, v, c='') => `<div class="sr"><span class="sl">${l}</span><span class="sv ${c}">${v}</span></div>`;
const set = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };

// ─── NAV ─────────────────────────────────────
function nav(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nb').forEach(b => b.classList.remove('active'));
  document.getElementById('page-' + page).classList.add('active');
  const pages = ['overview','cpu','memory','gpu','storage','network','temp','games','bench'];
  const i = pages.indexOf(page);
  const btns = document.querySelectorAll('.nb');
  if (i >= 0 && btns[i]) btns[i].classList.add('active');
}

// ─── MINI CHART ──────────────────────────────
function drawChart(id, data, color) {
  const canvas = document.getElementById(id);
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const w = canvas.parentElement.offsetWidth || 300;
  const h = canvas.parentElement.offsetHeight || 70;
  canvas.width = w * dpr; canvas.height = h * dpr;
  canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, w, h);
  const step = w / (data.length - 1);
  // grid
  ctx.strokeStyle = 'rgba(0,212,255,0.04)'; ctx.lineWidth = 1;
  [0.25, 0.5, 0.75].forEach(f => { ctx.beginPath(); ctx.moveTo(0,h*f); ctx.lineTo(w,h*f); ctx.stroke(); });
  // fill
  const hex = color.replace('#','');
  const r=parseInt(hex.slice(0,2),16), g=parseInt(hex.slice(2,4),16), b=parseInt(hex.slice(4,6),16);
  const grad = ctx.createLinearGradient(0,0,0,h);
  grad.addColorStop(0, `rgba(${r},${g},${b},0.28)`);
  grad.addColorStop(1, `rgba(${r},${g},${b},0)`);
  ctx.beginPath(); ctx.moveTo(0, h);
  data.forEach((v,i) => ctx.lineTo(i*step, h-(v/100)*h));
  ctx.lineTo((data.length-1)*step, h); ctx.closePath();
  ctx.fillStyle = grad; ctx.fill();
  // line
  ctx.beginPath();
  data.forEach((v,i) => i===0 ? ctx.moveTo(0,h-(v/100)*h) : ctx.lineTo(i*step,h-(v/100)*h));
  ctx.strokeStyle = color; ctx.lineWidth = 1.5; ctx.lineJoin = 'round'; ctx.stroke();
  // dot
  const lv = data[data.length-1];
  ctx.beginPath(); ctx.arc((data.length-1)*step, h-(lv/100)*h, 3, 0, Math.PI*2);
  ctx.fillStyle = color; ctx.fill();
}

// ─── STATIC ──────────────────────────────────
async function loadStatic() {
  set('ltxt', 'LENDO CPU...');
  staticData = await window.specview.getStaticInfo();
  if (staticData.error) return console.error(staticData.error);
  renderStatic();
  set('ltxt', 'PRONTO!');
  setTimeout(() => document.getElementById('loading').classList.add('hidden'), 500);
}

function renderStatic() {
  const { cpu, mem, os, gpu, disk, mb, bios } = staticData;
  const cpuName = `${cpu.manufacturer} ${cpu.brand}`;
  set('ov-cpu-name', cpuName);

  // OS
  document.getElementById('ov-os').innerHTML =
    sr('Sistema', `${os.distro} ${os.release}`, 'hi') +
    sr('Build', os.build || os.kernel) +
    sr('Arquitetura', os.arch, 'good') +
    sr('Hostname', os.hostname) +
    sr('BIOS', `${bios.vendor} ${bios.version}`);

  // CPU page
  document.getElementById('cpu-info').innerHTML =
    sr('Modelo', cpuName, 'hi') +
    sr('Fabricante', cpu.manufacturer) +
    sr('Clock Base', cpu.speed + ' GHz', 'good') +
    sr('Clock Máx', cpu.speedMax + ' GHz', 'hi') +
    sr('Núcleos Físicos', cpu.physicalCores, 'good') +
    sr('Threads', cpu.cores, 'good') +
    sr('Soquete', cpu.socket) +
    sr('Cache L2', cpu.cache?.l2 ? Math.round(cpu.cache.l2/1024)+' KB' : '—') +
    sr('Cache L3', cpu.cache?.l3 ? Math.round(cpu.cache.l3/1024/1024)+' MB' : '—') +
    sr('Virtualização', cpu.virtualization ? 'Sim' : 'Não', cpu.virtualization ? 'good' : '');

  // GPU page
  const gpus = gpu.controllers || [];
  document.getElementById('gpu-cards').innerHTML = gpus.length ? gpus.map(g =>
    `<div class="card" style="margin-bottom:10px">
      <div class="ch"><div class="ci" style="background:rgba(0,255,136,.1)">🎮</div><span class="ct">${g.model}</span></div>
      ${sr('Fabricante', g.vendor, 'hi')}
      ${sr('VRAM', g.vram ? g.vram+' MB' : '—', 'good')}
      ${sr('Tipo VRAM', g.vramDynamic ? 'Dinâmica' : 'Dedicada')}
      ${sr('Driver', g.driverVersion || '—')}
      ${sr('Resolução', g.currentResX ? g.currentResX+'x'+g.currentResY : '—', 'good')}
      ${sr('Taxa Refresh', g.currentRefreshRate ? g.currentRefreshRate+' Hz' : '—')}
    </div>`).join('') : sr('GPU','Não detectada','warn');

  document.getElementById('ov-gpu').innerHTML =
    gpus.length ? sr('Modelo', gpus[0].model, 'hi') + sr('VRAM', gpus[0].vram ? gpus[0].vram+' MB' : '—', 'good') + sr('Driver', gpus[0].driverVersion || '—') : sr('GPU','—');

  // Disk page
  document.getElementById('storage-cards').innerHTML = (disk||[]).map(d =>
    `<div class="card" style="margin-bottom:10px">
      <div class="ch"><div class="ci" style="background:rgba(255,215,0,.1)">💿</div><span class="ct">${d.type||'DISCO'}</span></div>
      ${sr('Modelo', d.name, 'hi')}
      ${sr('Tamanho', gb(d.size)+' GB', 'good')}
      ${sr('Tipo', d.type)}
      ${sr('Interface', d.interfaceType||'—')}
      ${sr('Fabricante', d.vendor||'—')}
    </div>`).join('') || sr('Disco','Não detectado','warn');

  // Motherboard
  document.getElementById('ov-mb').innerHTML =
    sr('Fabricante', mb.manufacturer, 'hi') +
    sr('Modelo', mb.model, 'good') +
    sr('Versão', mb.version) +
    sr('BIOS', `${bios.vendor} ${bios.version}`);

  // Memory
  set('m-total', gb(mem.total));
  document.getElementById('mem-details').innerHTML =
    sr('Total', gb(mem.total)+' GB', 'hi') +
    sr('Swap Total', gb(mem.swaptotal)+' GB') +
    sr('Swap Usado', gb(mem.swapused)+' GB', mem.swapused > mem.swaptotal*0.7 ? 'warn' : '');

  // Init games with hardware data
  initGames(cpu, mem, gpus);
}

// ─── DYNAMIC ─────────────────────────────────
async function updateDynamic() {
  const d = await window.specview.getDynamicInfo();
  if (!d || d.error) return;
  const { cpuLoad, mem, cpuTemp, netStats, processes } = d;

  // CPU
  const cpuPct = (cpuLoad.currentLoad || 0).toFixed(1);
  chartData.cpu.push(parseFloat(cpuPct));
  if (chartData.cpu.length > 60) chartData.cpu.shift();
  set('ov-cpu-pct', cpuPct + '%');
  set('cpu-rt-pct', cpuPct + '%');
  set('sb-cpu', cpuPct + '%');
  const badge = document.getElementById('ov-cpu-badge');
  if (badge) {
    badge.textContent = cpuPct > 80 ? 'ALTO' : cpuPct > 50 ? 'MÉDIO' : 'NORMAL';
    badge.style.color = cpuPct > 80 ? 'var(--neon3)' : cpuPct > 50 ? '#ffd700' : 'var(--neon2)';
  }

  // CPU cores
  const cores = cpuLoad.cpus || [];
  const coresEl = document.getElementById('cpu-cores');
  if (coresEl) coresEl.innerHTML = cores.slice(0,16).map((c,i) => {
    const p = (c.load||0).toFixed(0);
    const col = p>80?'var(--neon3)':p>50?'#ffd700':'var(--neon)';
    return `<div class="br"><span class="bl">Core ${i+1}</span><div class="bt"><div class="bf" style="width:${p}%;background:${col}"></div></div><span class="bp">${p}%</span></div>`;
  }).join('');

  // RAM
  const usedPct = parseFloat(pct(mem.active||mem.used, mem.total));
  const freePct = parseFloat(pct(mem.available||mem.free, mem.total));
  const cachePct = Math.max(0, 100 - usedPct - freePct);
  chartData.ram.push(usedPct);
  if (chartData.ram.length > 60) chartData.ram.shift();
  set('ov-ram-pct', usedPct.toFixed(1)+'%');
  set('ov-ram-sub', gb(mem.active||mem.used)+' / '+gb(mem.total)+' GB');
  set('sb-ram', gb(mem.active||mem.used)+'GB');
  const ramBadge = document.getElementById('ov-ram-badge');
  if (ramBadge) ramBadge.textContent = gb(mem.active||mem.used)+'/'+gb(mem.total)+'GB';
  set('m-used', gb(mem.active||mem.used));
  set('m-free', gb(mem.available||mem.free));
  const setBar = (id,pid,v) => { const e=document.getElementById(id); if(e)e.style.width=v+'%'; const p=document.getElementById(pid); if(p)p.textContent=v.toFixed(0)+'%'; };
  setBar('mb-used','mp-used',usedPct);
  setBar('mb-cache','mp-cache',cachePct);
  setBar('mb-free','mp-free',freePct);

  // TEMPERATURE — pega todos os sensores disponíveis
  const temps = cpuTemp || {};
  const mainTemp = temps.main > 0 ? temps.main : null;
  const coreTemps = (temps.cores || []).filter(t => t > 0);
  const maxTemp = coreTemps.length ? Math.max(...coreTemps) : mainTemp;
  const gpuTemp = temps.gpu > 0 ? temps.gpu : null;

  const tStr = t => t ? t+'°C' : 'N/A';
  const tCls = t => t ? tempColor(t) : 'warn';

  set('ov-tcpu', tStr(mainTemp));
  set('ov-tgpu', tStr(gpuTemp));
  set('ov-tmax', tStr(maxTemp));
  set('sb-temp', tStr(mainTemp || maxTemp));

  const tcpuEl = document.getElementById('ov-tcpu');
  const tgpuEl = document.getElementById('ov-tgpu');
  const tmaxEl = document.getElementById('ov-tmax');
  if (tcpuEl) tcpuEl.className = 'tv ' + tCls(mainTemp);
  if (tgpuEl) tgpuEl.className = 'tv ' + tCls(gpuTemp);
  if (tmaxEl) tmaxEl.className = 'tv ' + tCls(maxTemp);

  // Temp page
  const tempEl = document.getElementById('temp-cards');
  if (tempEl) {
    if (coreTemps.length > 0 || mainTemp || gpuTemp) {
      let html = '';
      if (mainTemp) html += `<div class="card"><div class="metric"><div class="mv ${tCls(mainTemp)}">${mainTemp}°C</div><div class="ml">CPU — MÉDIA</div></div></div>`;
      if (gpuTemp)  html += `<div class="card"><div class="metric"><div class="mv ${tCls(gpuTemp)}">${gpuTemp}°C</div><div class="ml">GPU</div></div></div>`;
      if (maxTemp)  html += `<div class="card"><div class="metric"><div class="mv ${tCls(maxTemp)}">${maxTemp}°C</div><div class="ml">MÁXIMA</div></div></div>`;
      coreTemps.forEach((t,i) => {
        html += `<div class="card"><div class="metric"><div class="mv ${tCls(t)}">${t}°C</div><div class="ml">CORE ${i+1}</div></div></div>`;
      });
      tempEl.innerHTML = html;
    } else {
      tempEl.innerHTML = `<div class="card cf"><div class="sr"><span class="sv warn" style="max-width:100%;text-align:center;width:100%">Nenhum sensor detectado. Execute como Administrador para leitura de temperatura.</span></div></div>`;
    }
  }

  // Network
  const net = netStats?.[0];
  if (net) {
    const dl = mb2(net.rx_sec||0);
    const ul = mb2(net.tx_sec||0);
    chartData.net.push(Math.min(100, parseFloat(dl)*5));
    if (chartData.net.length > 60) chartData.net.shift();
    set('net-dl', dl); set('net-ul', ul);
    set('sb-net', dl+' MB/s');
    const ni = document.getElementById('net-info');
    if (ni) ni.innerHTML =
      sr('Interface', net.iface, 'hi') +
      sr('Total Recebido', gb(net.rx_bytes)+' GB', 'good') +
      sr('Total Enviado', gb(net.tx_bytes)+' GB') +
      sr('Erros RX', net.rx_errors||0) +
      sr('Erros TX', net.tx_errors||0);
  }

  // Processes
  const procs = (processes?.list||[]).filter(p=>p.cpu>0.1).sort((a,b)=>b.cpu-a.cpu).slice(0,12);
  const pl = document.getElementById('proc-list');
  if (pl && procs.length) pl.innerHTML = procs.map(p =>
    `<div class="prow"><span class="pname">${p.name}</span><span class="pcpu">${p.cpu.toFixed(1)}%</span><span class="pmem">${(p.memRss/1e6).toFixed(0)}MB</span></div>`
  ).join('');

  // Charts
  drawChart('ch-cpu-ov', chartData.cpu, '#00d4ff');
  drawChart('ch-ram-ov', chartData.ram, '#a855f7');
  drawChart('ch-cpu-rt', chartData.cpu, '#00d4ff');
  drawChart('ch-ram-rt', chartData.ram, '#a855f7');
  drawChart('ch-net',    chartData.net, '#00ff88');
}

// ─── GAMES DATABASE ───────────────────────────
// Banco de dados local com requisitos de jogos populares
const GAMES_DB = [
  { name:'Valorant', icon:'🎯', genre:'FPS Tático',
    min:{ cpu:'Intel Core i3-4150', ram:4, gpu:'GeForce GT 730', vram:1 },
    rec:{ cpu:'Intel Core i5-9400F', ram:8, gpu:'GeForce GTX 1050 Ti', vram:4 },
    minCores:2, recCores:4, minClock:3.1, recClock:3.9 },
  { name:'CS2 (Counter-Strike 2)', icon:'💣', genre:'FPS Tático',
    min:{ cpu:'Intel Core i5-8600K', ram:8, gpu:'GeForce GTX 970', vram:4 },
    rec:{ cpu:'Intel Core i7-9700K', ram:16, gpu:'GeForce GTX 1080 Ti', vram:8 },
    minCores:4, recCores:6, minClock:3.6, recClock:3.6 },
  { name:'GTA V', icon:'🚗', genre:'Ação/Mundo Aberto',
    min:{ cpu:'Intel Core i5-3470', ram:8, gpu:'GeForce GTX 660', vram:2 },
    rec:{ cpu:'Intel Core i5-6600K', ram:16, gpu:'GeForce GTX 1060', vram:6 },
    minCores:4, recCores:4, minClock:3.2, recClock:3.5 },
  { name:'Minecraft', icon:'⛏', genre:'Sobrevivência/Sandbox',
    min:{ cpu:'Intel Core i3-3210', ram:4, gpu:'GeForce 400', vram:0.5 },
    rec:{ cpu:'Intel Core i5-4690', ram:8, gpu:'GeForce 700', vram:2 },
    minCores:2, recCores:4, minClock:2.0, recClock:3.5 },
  { name:'Fortnite', icon:'🏝', genre:'Battle Royale',
    min:{ cpu:'Intel Core i3-3225', ram:8, gpu:'Intel HD 4000', vram:1 },
    rec:{ cpu:'Intel Core i7-8700', ram:16, gpu:'GeForce GTX 1080', vram:8 },
    minCores:2, recCores:6, minClock:3.3, recClock:3.2 },
  { name:'Cyberpunk 2077', icon:'🤖', genre:'RPG / Mundo Aberto',
    min:{ cpu:'Intel Core i7-6700K', ram:8, gpu:'GeForce GTX 1060', vram:6 },
    rec:{ cpu:'Intel Core i7-8700K', ram:12, gpu:'GeForce RTX 2060', vram:6 },
    minCores:4, recCores:6, minClock:4.0, recClock:3.7 },
  { name:'League of Legends', icon:'⚔', genre:'MOBA',
    min:{ cpu:'Intel Core i5-3300', ram:4, gpu:'GeForce 9600M GS', vram:0.5 },
    rec:{ cpu:'Intel Core i5-3300', ram:8, gpu:'Nvidia GeForce 560', vram:1 },
    minCores:2, recCores:4, minClock:2.0, recClock:2.0 },
  { name:'Apex Legends', icon:'🦊', genre:'Battle Royale FPS',
    min:{ cpu:'Intel Core i3-6300', ram:6, gpu:'GeForce GTX 970', vram:4 },
    rec:{ cpu:'Intel Core i5-8600', ram:8, gpu:'GeForce RTX 2070', vram:8 },
    minCores:4, recCores:6, minClock:3.8, recClock:3.4 },
  { name:'Red Dead Redemption 2', icon:'🤠', genre:'Ação/Aventura',
    min:{ cpu:'Intel Core i7-4770K', ram:8, gpu:'GeForce GTX 1060', vram:6 },
    rec:{ cpu:'Intel Core i7-4770K', ram:12, gpu:'GeForce GTX 1070', vram:8 },
    minCores:4, recCores:4, minClock:3.5, recClock:3.5 },
  { name:'The Witcher 3', icon:'🗡', genre:'RPG',
    min:{ cpu:'Intel Core i5-2500K', ram:6, gpu:'GeForce GTX 660', vram:2 },
    rec:{ cpu:'Intel Core i7-3770', ram:8, gpu:'GeForce GTX 770', vram:4 },
    minCores:4, recCores:4, minClock:3.3, recClock:3.4 },
  { name:'Elden Ring', icon:'💍', genre:'RPG/Action',
    min:{ cpu:'Intel Core i5-8600K', ram:12, gpu:'GeForce GTX 1060', vram:6 },
    rec:{ cpu:'Intel Core i7-8700K', ram:16, gpu:'GeForce GTX 1070', vram:8 },
    minCores:6, recCores:6, minClock:3.6, recClock:3.7 },
  { name:'FIFA 24', icon:'⚽', genre:'Esportes',
    min:{ cpu:'Intel Core i5-6600K', ram:8, gpu:'GeForce GTX 1050 Ti', vram:4 },
    rec:{ cpu:'Intel Core i7-6700', ram:16, gpu:'GeForce RTX 2070', vram:8 },
    minCores:4, recCores:4, minClock:3.5, recClock:3.4 },
  { name:'Overwatch 2', icon:'🦸', genre:'FPS Hero',
    min:{ cpu:'Intel Core i3-6100', ram:6, gpu:'GeForce GTX 600', vram:2 },
    rec:{ cpu:'Intel Core i7-8700K', ram:8, gpu:'GeForce GTX 1060', vram:6 },
    minCores:4, recCores:6, minClock:3.7, recClock:3.7 },
  { name:'Hogwarts Legacy', icon:'🪄', genre:'RPG/Aventura',
    min:{ cpu:'Intel Core i7-8700', ram:16, gpu:'GeForce GTX 1080 Ti', vram:8 },
    rec:{ cpu:'Intel Core i7-8700', ram:16, gpu:'GeForce RTX 2080', vram:8 },
    minCores:6, recCores:6, minClock:3.2, recClock:3.2 },
  { name:'Starfield', icon:'🚀', genre:'RPG/Sci-Fi',
    min:{ cpu:'Intel Core i7-6800K', ram:16, gpu:'GeForce GTX 1070 Ti', vram:8 },
    rec:{ cpu:'Intel Core i7-7800X', ram:16, gpu:'GeForce RTX 2080', vram:8 },
    minCores:6, recCores:6, minClock:3.4, recClock:3.5 },
  { name:'Forza Horizon 5', icon:'🏎', genre:'Corrida',
    min:{ cpu:'Intel Core i5-8400', ram:8, gpu:'GeForce GTX 970', vram:4 },
    rec:{ cpu:'Intel Core i7-10700K', ram:16, gpu:'GeForce RTX 3080', vram:10 },
    minCores:6, recCores:8, minClock:2.8, recClock:3.8 },
  { name:'Call of Duty Warzone', icon:'🔫', genre:'Battle Royale FPS',
    min:{ cpu:'Intel Core i3-4340', ram:8, gpu:'GeForce GTX 670', vram:2 },
    rec:{ cpu:'Intel Core i7-8700K', ram:16, gpu:'GeForce RTX 2080', vram:8 },
    minCores:4, recCores:6, minClock:3.6, recClock:3.7 },
  { name:'Roblox', icon:'🧱', genre:'Plataforma/Sandbox',
    min:{ cpu:'Intel Core i5', ram:4, gpu:'GeForce 9600M', vram:0.5 },
    rec:{ cpu:'Intel Core i7', ram:8, gpu:'GeForce GTX 970', vram:4 },
    minCores:2, recCores:4, minClock:1.6, recClock:2.5 },
  { name:'Among Us', icon:'🟣', genre:'Party Game',
    min:{ cpu:'Intel Core i5', ram:2, gpu:'DirectX 11', vram:0.5 },
    rec:{ cpu:'Intel Core i7', ram:4, gpu:'GeForce GTX 1050', vram:2 },
    minCores:2, recCores:4, minClock:1.0, recClock:2.0 },
  { name:'Diablo IV', icon:'👹', genre:'Action RPG',
    min:{ cpu:'Intel Core i5-4670K', ram:8, gpu:'GeForce GTX 970', vram:4 },
    rec:{ cpu:'Intel Core i7-8700K', ram:32, gpu:'GeForce RTX 2060', vram:6 },
    minCores:4, recCores:6, minClock:3.4, recClock:3.7 },
  { name:'Palworld', icon:'🐉', genre:'Survival/Sandbox',
    min:{ cpu:'Intel Core i5-4430', ram:16, gpu:'GeForce GTX 1050', vram:4 },
    rec:{ cpu:'Intel Core i9-9900K', ram:32, gpu:'GeForce RTX 2070', vram:8 },
    minCores:4, recCores:8, minClock:3.0, recClock:3.6 },
  { name:'Baldur\'s Gate 3', icon:'🎲', genre:'RPG',
    min:{ cpu:'Intel Core i7-8700K', ram:8, gpu:'GeForce GTX 1060', vram:6 },
    rec:{ cpu:'Intel Core i7-8700K', ram:16, gpu:'GeForce RTX 2060', vram:6 },
    minCores:6, recCores:6, minClock:3.7, recClock:3.7 },
  { name:'Hades', icon:'💀', genre:'Roguelike',
    min:{ cpu:'Intel Core i5-2400', ram:8, gpu:'GeForce GTX 650 Ti', vram:1 },
    rec:{ cpu:'Intel Core i7-4000', ram:16, gpu:'GeForce GTX 970', vram:4 },
    minCores:4, recCores:4, minClock:3.1, recClock:3.0 },
  { name:'Sea of Thieves', icon:'🏴‍☠️', genre:'Aventura',
    min:{ cpu:'Intel Core i5-4690', ram:8, gpu:'GeForce GTX 660', vram:2 },
    rec:{ cpu:'Intel Core i7-4790', ram:16, gpu:'GeForce GTX 980', vram:4 },
    minCores:4, recCores:4, minClock:3.5, recClock:3.6 },
  { name:'Hollow Knight', icon:'🦋', genre:'Metroidvania',
    min:{ cpu:'Intel Core i5', ram:4, gpu:'GeForce GTX 560', vram:1 },
    rec:{ cpu:'Intel Core i7', ram:8, gpu:'GeForce GTX 770', vram:2 },
    minCores:2, recCores:4, minClock:2.0, recClock:2.5 },
];

// Popular suggestions
const POPULAR = ['Valorant','CS2 (Counter-Strike 2)','GTA V','Fortnite','Minecraft','Cyberpunk 2077','League of Legends','Apex Legends'];

let hwCpu = null, hwRam = 0, hwGpu = null;

function initGames(cpu, mem, gpus) {
  hwCpu = cpu;
  hwRam = mem.total / 1e9;
  hwGpu = gpus[0] || null;

  // Render suggestion chips
  const sugEl = document.getElementById('sug-list');
  if (sugEl) sugEl.innerHTML = POPULAR.map(name =>
    `<span class="sug-chip" onclick="quickSearch('${name}')">${name}</span>`
  ).join('');
}

function quickSearch(name) {
  document.getElementById('game-input').value = name;
  searchGame(name);
}

function clearGame() {
  document.getElementById('game-input').value = '';
  document.getElementById('game-result-area').innerHTML = '';
  document.getElementById('game-suggestions').style.display = '';
}

function searchGame(query) {
  query = (query||'').trim().toLowerCase();
  const area = document.getElementById('game-result-area');
  const sugs = document.getElementById('game-suggestions');
  if (!query) { area.innerHTML = ''; sugs.style.display=''; return; }
  sugs.style.display = 'none';

  const matches = GAMES_DB.filter(g => g.name.toLowerCase().includes(query));
  if (!matches.length) {
    area.innerHTML = `<div class="no-game">
      <div style="font-size:32px;margin-bottom:10px">🔍</div>
      <div>"${query}" não encontrado no banco de dados</div>
      <div style="margin-top:6px;font-size:10px">Tente outro nome ou verifique a grafia</div>
    </div>`;
    return;
  }
  area.innerHTML = matches.slice(0,5).map(g => renderGameCard(g)).join('');
}

function checkCompat(game) {
  if (!hwCpu || !hwRam) return { verdict:'warn', label:'Hardware não detectado' };

  const cores = hwCpu.cores || 4;
  const clock = hwCpu.speedMax || hwCpu.speed || 2.5;
  const ramGB = hwRam;
  const vramMB = hwGpu?.vram || 0;
  const vramGB = vramMB / 1024;

  // Check minimum
  const meetsMinCores = cores >= game.minCores;
  const meetsMinClock = clock >= game.minClock;
  const meetsMinRam   = ramGB >= game.min.ram;
  const meetsMinVram  = vramGB >= game.min.vram;
  const meetsMin = meetsMinCores && meetsMinClock && meetsMinRam && meetsMinVram;

  // Check recommended
  const meetsRecCores = cores >= game.recCores;
  const meetsRecClock = clock >= game.recClock;
  const meetsRecRam   = ramGB >= game.rec.ram;
  const meetsRecVram  = vramGB >= game.rec.vram;
  const meetsRec = meetsRecCores && meetsRecClock && meetsRecRam && meetsRecVram;

  return {
    verdict: meetsRec ? 'yes' : meetsMin ? 'low' : 'no',
    label:   meetsRec ? '✓ RODA BEM' : meetsMin ? '⚠ RODA (MÍNIMO)' : '✕ NÃO RODA',
    details: { meetsMinCores, meetsMinClock, meetsMinRam, meetsMinVram, meetsRecCores, meetsRecClock, meetsRecRam, meetsRecVram },
    cores, clock, ramGB, vramGB
  };
}

function fpsEstimate(game, compat) {
  if (compat.verdict === 'no') return { low:0, med:0, high:0, ultra:0 };
  const factor = compat.verdict === 'yes' ? 1.0 : 0.5;
  // Rough estimates based on hardware vs recommended
  const baseFps = compat.verdict === 'yes' ? 90 : 35;
  return {
    low:   Math.round(baseFps * 1.6 * factor),
    med:   Math.round(baseFps * 1.1 * factor),
    high:  Math.round(baseFps * 0.7 * factor),
    ultra: Math.round(baseFps * 0.45 * factor)
  };
}

function renderGameCard(game) {
  const compat = checkCompat(game);
  const fps = fpsEstimate(game, compat);
  const { details: d } = compat;

  const reqRow = (label, minVal, recVal, meets, meetsRec) =>
    `<div class="req-row">
      <span class="req-lbl">${label}</span>
      <span class="req-val ${meetsRec?'req-ok':meets?'req-warn':'req-fail'}">${meetsRec?'✓':meets?'~':'✕'} ${minVal}</span>
    </div>`;

  const fpsBar = (label, val, max, color) =>
    `<div class="fps-row">
      <span class="fps-ql">${label}</span>
      <div class="fps-track"><div class="fps-fill" style="width:${Math.min(100,val/max*100)}%;background:${color}"></div></div>
      <span class="fps-num ${val>=60?'good':val>=30?'warn':'danger'}">${val} FPS</span>
    </div>`;

  return `
  <div class="game-result">
    <div class="game-header">
      <span class="game-icon">${game.icon}</span>
      <div><div class="game-name">${game.name}</div><div class="game-genre">${game.genre}</div></div>
      <div class="game-verdict verdict-${compat.verdict}">${compat.label}</div>
    </div>
    <div class="req-grid">
      <div class="req-box">
        <div class="req-title">REQUISITOS MÍNIMOS</div>
        ${reqRow('CPU', game.minCores+' núcleos', game.recCores+' núcleos', d.meetsMinCores, d.meetsRecCores)}
        ${reqRow('Clock', game.minClock+' GHz', game.recClock+' GHz', d.meetsMinClock, d.meetsRecClock)}
        ${reqRow('RAM', game.min.ram+' GB', game.rec.ram+' GB', d.meetsMinRam, d.meetsRecRam)}
        ${reqRow('VRAM', game.min.vram+' GB', game.rec.vram+' GB', d.meetsMinVram, d.meetsRecVram)}
      </div>
      <div class="req-box">
        <div class="req-title">SEU HARDWARE</div>
        ${sr('CPU', hwCpu?.brand || '—', 'hi')}
        ${sr('Núcleos', (compat.cores||'—')+' threads', compat.cores >= game.recCores?'good':compat.cores >= game.minCores?'warn':'danger')}
        ${sr('RAM', compat.ramGB.toFixed(1)+' GB', compat.ramGB >= game.rec.ram?'good':compat.ramGB >= game.min.ram?'warn':'danger')}
        ${sr('VRAM', compat.vramGB.toFixed(1)+' GB', compat.vramGB >= game.rec.vram?'good':compat.vramGB >= game.min.vram?'warn':'danger')}
      </div>
    </div>
    ${compat.verdict !== 'no' ? `
    <div class="fps-estimate">
      <div class="fps-title">ESTIMATIVA DE FPS (use MSI Afterburner para leitura real)</div>
      <div class="fps-bars">
        ${fpsBar('Baixo', fps.low, 200, '#00ff88')}
        ${fpsBar('Médio', fps.med, 200, '#00d4ff')}
        ${fpsBar('Alto', fps.high, 200, '#a855f7')}
        ${fpsBar('Ultra', fps.ultra, 200, '#ff6b35')}
      </div>
    </div>` : `<div class="fps-estimate" style="text-align:center;color:var(--neon3);font-family:var(--fm);font-size:11px;padding:12px">
      ✕ Hardware abaixo dos requisitos mínimos — Jogo não roda neste PC
    </div>`}
  </div>`;
}

// ─── BENCHMARK ───────────────────────────────
let benchRunning = false;
async function runBenchmark() {
  if (benchRunning) return;
  benchRunning = true;
  const btn = document.getElementById('bench-btn');
  const status = document.getElementById('bench-status');
  btn.textContent = '⏳ EXECUTANDO...'; btn.disabled = true;
  set('bench-status', 'Rodando testes no processo Node.js...');
  ['b-cpu','b-mem','b-gfx','b-tot'].forEach(id => set(id, '…'));
  ['bp-cpu','bp-mem','bp-gfx','bp-tot'].forEach(id => { const e=document.getElementById(id); if(e)e.style.width='0%'; });
  set('b-rank', '');

  const r = await window.specview.runBenchmark();
  animScore('b-cpu','bp-cpu', r.cpu, 9999);
  animScore('b-mem','bp-mem', r.mem, 9999);
  animScore('b-gfx','bp-gfx', r.gfx, 9999);
  await new Promise(res => setTimeout(res, 900));
  animScore('b-tot','bp-tot', r.total, 9999);

  const rank = r.total>8000?'🏆 EXCELENTE':r.total>6000?'🥇 MUITO BOM':r.total>4000?'🥈 BOM':'🥉 BÁSICO';
  set('b-rank', rank);
  set('bench-status', `Concluído — Total: ${r.total.toLocaleString('pt-BR')}`);
  btn.textContent = '▶ EXECUTAR BENCHMARK'; btn.disabled = false;
  benchRunning = false;
}

function animScore(id, progId, val, max) {
  let cur = 0; const step = val / 40;
  const t = setInterval(() => {
    cur = Math.min(cur+step, val);
    set(id, Math.round(cur).toLocaleString('pt-BR'));
    const p = document.getElementById(progId); if(p) p.style.width=(cur/max*100)+'%';
    if (cur >= val) clearInterval(t);
  }, 25);
}

// ─── SHARE ───────────────────────────────────
function openShare() {
  if (!staticData) return;
  const { cpu, mem, os, gpu } = staticData;
  const g = gpu.controllers?.[0];
  const txt = `
╔═══════════════════════════════════════╗
║       SPECVIEW v3.0 — RELATÓRIO       ║
╠═══════════════════════════════════════╣
║ CPU:  ${(cpu.manufacturer+' '+cpu.brand).substring(0,37).padEnd(37)} ║
║ Cor:  ${String(cpu.cores).padEnd(37)} ║
║ RAM:  ${(gb(mem.total)+' GB').padEnd(37)} ║
║ GPU:  ${(g?.model||'N/A').substring(0,37).padEnd(37)} ║
║ VRAM: ${(g?.vram ? g.vram+' MB' : 'N/A').padEnd(37)} ║
║ OS:   ${(os.distro+' '+os.release).substring(0,37).padEnd(37)} ║
║ Arq:  ${os.arch.padEnd(37)} ║
╚═══════════════════════════════════════╝
${new Date().toLocaleString('pt-BR')} — SpecView Desktop v3.0`.trim();
  document.getElementById('share-txt').textContent = txt;
  document.getElementById('modal').classList.add('open');
}
async function copyShare() {
  await navigator.clipboard.writeText(document.getElementById('share-txt').textContent);
  const btn = event.target; btn.textContent='✓ Copiado!';
  setTimeout(()=>btn.textContent='📋 Copiar',2000);
}
function closeModal() { document.getElementById('modal').classList.remove('open'); }

// ─── CLOCK ───────────────────────────────────
function clock() { set('sb-clock', new Date().toLocaleTimeString('pt-BR')); }

// ─── INIT ────────────────────────────────────
async function init() {
  await loadStatic();
  await updateDynamic();
  setInterval(updateDynamic, 2000);
  setInterval(clock, 1000);
  clock();
}

document.getElementById('modal').addEventListener('click', e => { if(e.target===document.getElementById('modal')) closeModal(); });
init();
