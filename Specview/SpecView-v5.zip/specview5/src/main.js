const { app, BrowserWindow, ipcMain, Tray, Menu, nativeImage } = require('electron');
const path = require('path');
const si = require('systeminformation');

let mainWindow;
let tray;
let isQuitting = false;

function getTrayIcon() {
  try {
    const img = nativeImage.createFromPath(path.join(__dirname, '../assets/icon.ico'));
    if (!img.isEmpty()) return img.resize({ width: 16, height: 16 });
  } catch (e) {}
  return nativeImage.createEmpty();
}

function createTray() {
  tray = new Tray(getTrayIcon());
  tray.setToolTip('SpecView - Monitor de Hardware');
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Abrir SpecView', click: () => { mainWindow.show(); mainWindow.focus(); } },
    { type: 'separator' },
    { label: 'Sair do SpecView', click: () => { isQuitting = true; app.quit(); } }
  ]));
  tray.on('click', () => {
    if (mainWindow.isVisible()) mainWindow.hide();
    else { mainWindow.show(); mainWindow.focus(); }
  });
  tray.on('double-click', () => { mainWindow.show(); mainWindow.focus(); });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280, height: 860, minWidth: 960, minHeight: 640,
    frame: false, backgroundColor: '#030b12',
    webPreferences: {
      nodeIntegration: false, contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    icon: path.join(__dirname, '../assets/icon.ico'),
    show: false
  });
  mainWindow.loadFile(path.join(__dirname, 'index.html'));
  mainWindow.setMenuBarVisibility(false);
  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.on('close', (e) => {
    if (!isQuitting) {
      e.preventDefault();
      mainWindow.hide();
      try {
        tray.displayBalloon({
          title: 'SpecView continua rodando',
          content: 'Clique no icone da bandeja para reabrir.',
          iconType: 'info'
        });
      } catch(e) {}
    }
  });
}

app.whenReady().then(() => { createTray(); createWindow(); });
app.on('before-quit', () => { isQuitting = true; });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

// STATIC INFO
ipcMain.handle('get-static-info', async () => {
  try {
    const [cpu, mem, os, gpu, disk, mb, bios] = await Promise.all([
      si.cpu(), si.mem(), si.osInfo(), si.graphics(),
      si.diskLayout(), si.baseboard(), si.bios()
    ]);
    return { cpu, mem, os, gpu, disk, mb, bios };
  } catch (e) { return { error: e.message }; }
});

// DYNAMIC INFO
ipcMain.handle('get-dynamic-info', async () => {
  try {
    const [cpuLoad, mem, cpuTemp, netStats, processes] = await Promise.all([
      si.currentLoad(), si.mem(), si.cpuTemperature(),
      si.networkStats(), si.processes()
    ]);
    return { cpuLoad, mem, cpuTemp, netStats, processes };
  } catch (e) { return { error: e.message }; }
});

// BENCHMARK
ipcMain.handle('run-benchmark', async () => {
  const t0 = Date.now();
  let s = 0;
  for (let i = 0; i < 5000000; i++) s += Math.sqrt(i) * Math.sin(i);
  const cpu = Math.round(Math.max(1000, Math.min(9999, 1e9 / (Date.now() - t0))));

  const t1 = Date.now();
  const arr = new Float64Array(1000000);
  for (let i = 0; i < arr.length; i++) arr[i] = Math.random();
  arr.sort();
  const mem = Math.round(Math.max(1000, Math.min(9999, 5e7 / (Date.now() - t1))));

  const t2 = Date.now();
  const mat = Array.from({length:80}, () => Array.from({length:80}, () => Math.random()));
  let sum = 0;
  for (let i=0;i<80;i++) for(let j=0;j<80;j++) for(let k=0;k<80;k++) sum+=mat[i][k]*mat[k][j];
  const gfx = Math.round(Math.max(1000, Math.min(9999, 5e7 / (Date.now() - t2))));

  return { cpu, mem, gfx, total: Math.round(cpu*0.45 + mem*0.25 + gfx*0.3) };
});

// WINDOW CONTROLS
ipcMain.on('window-minimize', () => mainWindow.minimize());
ipcMain.on('window-maximize', () => mainWindow.isMaximized() ? mainWindow.unmaximize() : mainWindow.maximize());
ipcMain.on('window-hide', () => mainWindow.hide());
ipcMain.on('window-close', () => { isQuitting = true; app.quit(); });
