@echo off
title SpecView v7 - Instalador
color 0B
cls

echo.
echo  ================================
echo   SPECVIEW v7 - Hardware Monitor
echo  ================================
echo.

:: Verifica Node.js
echo [1/4] Verificando Node.js...
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Node.js nao encontrado. Abrindo download...
    start https://nodejs.org/dist/v20.10.0/node-v20.10.0-x64.msi
    echo.
    echo Instale o Node.js, reinicie o PC e execute este arquivo novamente.
    pause
    exit /b 1
)
for /f "tokens=*" %%v in ('node --version') do set NODEVER=%%v
echo [OK] Node.js %NODEVER% encontrado!
echo.

:: Instala dependencias
echo [2/4] Instalando dependencias (aguarde 2-5 min)...
cd /d "%~dp0"
npm install 2>&1
if %errorlevel% neq 0 (
    echo ERRO ao instalar. Tente rodar como Administrador.
    pause
    exit /b 1
)
echo [OK] Dependencias instaladas!
echo.

:: Instala electron-builder globalmente para o compilar.bat funcionar
echo [3/4] Instalando electron-builder...
npm install electron-builder --save-dev 2>&1
echo [OK] electron-builder pronto!
echo.

:: Cria atalho na area de trabalho via VBScript puro (sem PowerShell)
echo [4/4] Criando atalho na Area de Trabalho...
set PASTA=%~dp0

:: Cria o launcher.vbs que abre sem janela preta
(
echo Set oWS = WScript.CreateObject^("WScript.Shell"^)
echo oWS.CurrentDirectory = "%PASTA%"
echo oWS.Run "cmd /c npm start", 0, False
) > "%PASTA%launcher.vbs"

:: Cria o atalho .lnk via VBScript separado
(
echo Set oWS = WScript.CreateObject^("WScript.Shell"^)
echo sLinkFile = oWS.SpecialFolders^("Desktop"^) ^& "\SpecView.lnk"
echo Set oLink = oWS.CreateShortcut^(sLinkFile^)
echo oLink.TargetPath = "wscript.exe"
echo oLink.Arguments = """%PASTA%launcher.vbs"""
echo oLink.WorkingDirectory = "%PASTA%"
echo oLink.Description = "SpecView - Monitor de Hardware"
echo oLink.IconLocation = "%PASTA%assets\icon.ico"
echo oLink.Save
) > "%TEMP%\criar_atalho.vbs"

wscript "%TEMP%\criar_atalho.vbs"
del "%TEMP%\criar_atalho.vbs" >nul 2>&1

if exist "%USERPROFILE%\Desktop\SpecView.lnk" (
    echo [OK] Atalho criado na Area de Trabalho!
) else (
    echo [AVISO] Nao foi possivel criar o atalho automaticamente.
    echo [INFO] Use o iniciar.bat para abrir o app.
)

echo.
echo ================================
echo  INSTALACAO CONCLUIDA!
echo ================================
echo.
echo  - Proxima vez: clique em "SpecView" na Area de Trabalho
echo  - Abre sem janela preta, igual ao Discord!
echo  - Para temperatura: clique direito em iniciar.bat
echo    e escolha "Executar como administrador"
echo  - Para gerar .EXE: execute compilar.bat
echo.
set /p ABRIR=Abrir o SpecView agora? (S/N): 
if /i "%ABRIR%"=="S" wscript "%PASTA%launcher.vbs"
pause
