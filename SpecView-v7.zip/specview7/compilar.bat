@echo off
title SpecView - Compilar EXE
color 0E
cls

echo.
echo  ================================
echo   SPECVIEW - Gerar .EXE
echo  ================================
echo.
echo  Vai gerar na pasta dist\:
echo   - SpecView Setup.exe     (instalador)
echo   - SpecView-Portatil.exe  (portatil)
echo.
echo  Primeira vez pode demorar 15-20 min (baixa o Electron ~120MB).
echo  NAO feche esta janela!
echo.
pause

cd /d "%~dp0"

echo [1/3] Instalando dependencias...
npm install
if %errorlevel% neq 0 (
    echo ERRO: Falha no npm install. Execute instalar.bat primeiro.
    pause
    exit /b 1
)
echo [OK] Dependencias ok!
echo.

echo [2/3] Verificando electron-builder...
call npx electron-builder --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Instalando electron-builder...
    npm install electron-builder --save-dev
)
echo [OK] electron-builder ok!
echo.

echo [3/3] Compilando para Windows x64...
echo Aguarde, isso pode demorar alguns minutos...
echo.
call npx electron-builder --win nsis portable --x64

if %errorlevel% neq 0 (
    echo.
    echo ================================
    echo  ERRO na compilacao!
    echo ================================
    echo.
    echo Possiveis solucoes:
    echo  1. Clique direito neste arquivo e escolha
    echo     "Executar como administrador"
    echo  2. Desative o antivirus temporariamente
    echo  3. Verifique sua conexao com a internet
    echo.
    pause
    exit /b 1
)

echo.
echo ================================
echo  EXE gerado com sucesso!
echo ================================
echo.
echo  Arquivos na pasta dist\:
echo   - SpecView Setup X.X.X.exe  (instalador)
echo   - SpecView-Portatil.exe     (portatil)
echo.
set /p AB=Abrir pasta dist\? (S/N): 
if /i "%AB%"=="S" explorer "%~dp0dist"
pause
