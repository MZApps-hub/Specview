@echo off
cd /d "%~dp0"
if exist launcher.vbs (
    wscript launcher.vbs
) else (
    npm start
)
