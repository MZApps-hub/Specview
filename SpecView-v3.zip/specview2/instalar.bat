@echo off
title SpecView - Instalador
color 0B
cls

echo.
echo  ================================
echo   SPECVIEW - Monitor de Hardware
echo  ================================
echo.

echo [1/3] Verificando Node.js...
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  Node.js nao encontrado!
    echo  Abrindo pagina de download...
    echo  Instale o Node.js e execute este arquivo novamente.
    echo.
    start https://nodejs.org/dist/v20.10.0/node-v20.10.0-x64.msi
    echo Pressione qualquer tecla apos instalar o Node.js...
    pause >nul
    node --version >nul 2>&1
    if %errorlevel% neq 0 (
        echo ERRO: Node.js ainda nao detectado. Reinicie e tente novamente.
        pause
        exit /b 1
    )
)
echo [OK] Node.js encontrado!
echo.

echo [2/3] Instalando dependencias (aguarde 2-5 minutos)...
cd /d "%~dp0"
npm install
if %errorlevel% neq 0 (
    echo.
    echo ERRO ao instalar dependencias.
    echo Tente rodar como Administrador.
    pause
    exit /b 1
)
echo [OK] Dependencias instaladas!
echo.

echo [3/3] Criando atalho na Area de Trabalho...
set PASTA=%~dp0
echo @echo off > "%USERPROFILE%\Desktop\SpecView.bat"
echo cd /d "%PASTA%" >> "%USERPROFILE%\Desktop\SpecView.bat"
echo npm start >> "%USERPROFILE%\Desktop\SpecView.bat"
echo [OK] Atalho criado!
echo.

echo ================================
echo  SUCESSO! SpecView instalado!
echo ================================
echo.
echo  - Para abrir: clique em SpecView.bat na Area de Trabalho
echo  - Ou execute iniciar.bat nesta pasta
echo  - Para gerar .EXE: execute compilar.bat
echo.

set /p ABRIR=Deseja abrir o SpecView agora? (S/N): 
if /i "%ABRIR%"=="S" npm start

pause
